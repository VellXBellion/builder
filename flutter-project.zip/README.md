# GENETIC — Flutter Mobile App

Migrasi dari web project ke Flutter mobile app (Android/iOS).

## Setup

### 1. Buat project Flutter baru
```bash
flutter create genetic_app --org com.genetic
```

### 2. Replace file-file berikut
- Copy semua isi folder `lib/` ke project baru
- Replace `pubspec.yaml` dengan yang ada di sini
- Copy folder `assets/` ke project baru

### 3. Install dependencies
```bash
cd genetic_app
flutter pub get
```

### 4. Konfigurasi server URL
Edit `lib/services/api_service.dart`, ubah `_baseUrl` ke alamat server kamu:
```dart
static const String _baseUrl = 'http://YOUR_SERVER_IP:3000';
```

### 5. Run
```bash
flutter run
```

## Struktur Project

```
lib/
├── main.dart                    # Entry point
├── theme/
│   └── app_theme.dart           # Purple cyberpunk theme
├── models/
│   ├── user_model.dart          # User data model
│   └── device_model.dart        # Device data model
├── services/
│   ├── api_service.dart         # HTTP API client
│   ├── auth_service.dart        # Authentication state
│   └── socket_service.dart      # Socket.IO real-time
├── screens/
│   ├── splash_screen.dart       # Splash intro
│   ├── login_screen.dart        # Login page
│   ├── home_screen.dart         # Dashboard + Devices + Control
│   ├── admin_panel_screen.dart  # Account management
│   ├── settings_screen.dart     # Settings + password change
│   ├── about_screen.dart        # About page
│   ├── order_screen.dart        # Account purchase (QRIS)
│   └── helper_screen.dart       # Cache clear service (QRIS)
└── widgets/
    ├── glass_card.dart          # Reusable glass card
    ├── device_card.dart         # Device list item
    └── social_buttons.dart      # Telegram + TikTok buttons
```

## Fitur

- ✅ Login dengan save credentials
- ✅ Splash screen dengan countdown
- ✅ Dashboard dengan user info & trial countdown
- ✅ Device list dengan real-time status (Socket.IO)
- ✅ Full control panel (30+ device commands)
- ✅ Admin panel (CRUD akun, role hierarchy, quota)
- ✅ Settings (info akun, ganti password)
- ✅ About page dengan animasi
- ✅ Order page dengan QRIS payment
- ✅ Helper page (clear cache)
- ✅ Purple cyberpunk theme
- ✅ Social links (Telegram @ZenithIIX, TikTok @yudzx_01)

## Backend

Backend (server) tetap pakai Node.js yang sama (`sync.js`). 
Flutter app ini adalah **client/frontend** pengganti web.

## Build APK

```bash
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`
