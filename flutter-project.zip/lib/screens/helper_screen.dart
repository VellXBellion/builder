import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:qr_flutter/qr_flutter.dart';

import 'package:genetic_app/theme/app_theme.dart';
import 'package:genetic_app/services/api_service.dart';
import 'package:genetic_app/widgets/glass_card.dart';

class HelperScreen extends StatefulWidget {
  const HelperScreen({super.key});

  @override
  State<HelperScreen> createState() => _HelperScreenState();
}

class _HelperScreenState extends State<HelperScreen> {
  final _api = ApiService();
  final _usernameCtrl = TextEditingController();
  bool _submitting = false;
  bool _done = false;

  @override
  void dispose() {
    _usernameCtrl.dispose();
    super.dispose();
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: GoogleFonts.outfit(fontSize: 13)),
        backgroundColor:
            isError ? AppTheme.red.withOpacity(0.9) : AppTheme.green.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Future<void> _submit() async {
    final username = _usernameCtrl.text.trim();
    if (username.isEmpty) {
      _showSnackBar('Username harus diisi', isError: true);
      return;
    }

    setState(() => _submitting = true);
    try {
      final result = await _api.createHelper(username, 5000);
      if (result['success'] == true) {
        final invoiceId = result['invoiceId'] as String? ?? '';
        final qrUrl = result['qrUrl'] as String? ?? '';
        if (mounted) {
          _showPaymentSheet(invoiceId, qrUrl, username);
        }
      } else {
        _showSnackBar(result['message'] ?? 'Gagal membuat request', isError: true);
      }
    } catch (e) {
      _showSnackBar('Error: $e', isError: true);
    }
    setState(() => _submitting = false);
  }

  void _showPaymentSheet(String invoiceId, String qrUrl, String username) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _HelperPaymentSheet(
        api: _api,
        invoiceId: invoiceId,
        qrUrl: qrUrl,
        username: username,
        onSuccess: () {
          Navigator.pop(ctx);
          setState(() => _done = true);
          _showSnackBar('Cache berhasil di-clear!');
        },
        onCancel: () => Navigator.pop(ctx),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDeepest,
      appBar: AppBar(
        backgroundColor: AppTheme.bgDeepest.withOpacity(0.9),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppTheme.violetLight),
          onPressed: () => Navigator.pop(context),
        ),
        title: RichText(
          text: TextSpan(
            style: const TextStyle(
              fontFamily: 'Genetic',
              fontSize: 18,
              fontWeight: FontWeight.w700,
              letterSpacing: 3,
            ),
            children: const [
              TextSpan(text: 'GENETIC', style: TextStyle(color: AppTheme.textPrimary)),
              TextSpan(text: 'HELPER', style: TextStyle(color: AppTheme.fuchsia)),
            ],
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 20),

            // Icon
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    AppTheme.violet.withOpacity(0.2),
                    AppTheme.fuchsia.withOpacity(0.1),
                  ],
                ),
                border: Border.all(color: AppTheme.violet.withOpacity(0.3)),
                boxShadow: AppTheme.neonGlow,
              ),
              child: const Icon(
                Icons.cleaning_services_rounded,
                color: AppTheme.violetLight,
                size: 36,
              ),
            ),
            const SizedBox(height: 20),

            // Title
            Text(
              'GENETIC HELPER',
              style: GoogleFonts.rajdhani(
                fontSize: 24,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 8),

            // Description
            Text(
              'Layanan clear cache untuk akun Genetic.\nBiaya: Rp 5.000 per clear.',
              textAlign: TextAlign.center,
              style: GoogleFonts.outfit(
                fontSize: 14,
                color: AppTheme.textSecondary,
                height: 1.6,
              ),
            ),
            const SizedBox(height: 32),

            // Form
            if (_done) _buildDoneView() else _buildForm(),

            const SizedBox(height: 32),

            // Link back to login
            TextButton(
              onPressed: () =>
                  Navigator.pushNamedAndRemoveUntil(context, '/login', (_) => false),
              child: Text(
                'KEMBALI KE LOGIN',
                style: GoogleFonts.spaceMono(
                  fontSize: 10,
                  color: AppTheme.textMuted,
                  letterSpacing: 2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildForm() {
    return GlassCard(
      showShimmer: true,
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          TextField(
            controller: _usernameCtrl,
            style: GoogleFonts.outfit(
                fontSize: 14, color: AppTheme.textPrimary),
            decoration: const InputDecoration(
              labelText: 'USERNAME',
              prefixIcon: Icon(Icons.person_outline_rounded,
                  color: AppTheme.textMuted, size: 20),
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _submitting ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.violet.withOpacity(0.16),
                foregroundColor: AppTheme.violetLight,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(13)),
                side: BorderSide(color: AppTheme.violet.withOpacity(0.3)),
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: _submitting
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        color: AppTheme.violetLight,
                        strokeWidth: 2,
                      ),
                    )
                  : Text(
                      'BAYAR & CLEAR',
                      style: GoogleFonts.outfit(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 2.5,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDoneView() {
    return GlassCard(
      showGlow: true,
      showShimmer: true,
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppTheme.green.withOpacity(0.15),
              border: Border.all(color: AppTheme.green.withOpacity(0.4)),
            ),
            child: const Icon(Icons.check_rounded,
                color: AppTheme.green, size: 28),
          ),
          const SizedBox(height: 16),
          Text(
            'CACHE CLEARED',
            style: GoogleFonts.spaceMono(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppTheme.green,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Cache untuk akun "${_usernameCtrl.text.trim()}" berhasil dibersihkan.',
            textAlign: TextAlign.center,
            style: GoogleFonts.outfit(
                fontSize: 13, color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 16),
          TextButton(
            onPressed: () => setState(() => _done = false),
            child: Text(
              'CLEAR LAGI',
              style: GoogleFonts.spaceMono(
                fontSize: 10,
                color: AppTheme.violet,
                letterSpacing: 2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// Helper Payment Bottom Sheet
// =============================================================================

class _HelperPaymentSheet extends StatefulWidget {
  final ApiService api;
  final String invoiceId;
  final String qrUrl;
  final String username;
  final VoidCallback onSuccess;
  final VoidCallback onCancel;

  const _HelperPaymentSheet({
    required this.api,
    required this.invoiceId,
    required this.qrUrl,
    required this.username,
    required this.onSuccess,
    required this.onCancel,
  });

  @override
  State<_HelperPaymentSheet> createState() => _HelperPaymentSheetState();
}

class _HelperPaymentSheetState extends State<_HelperPaymentSheet> {
  late Timer _countdownTimer;
  late Timer _statusTimer;
  int _remainingSeconds = 5 * 60;
  final List<String> _logs = [];

  @override
  void initState() {
    super.initState();
    _addLog('Menunggu pembayaran Rp 5.000...');

    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_remainingSeconds <= 0) {
        _countdownTimer.cancel();
        _statusTimer.cancel();
        _addLog('Waktu habis. Pembayaran dibatalkan.');
        return;
      }
      setState(() => _remainingSeconds--);
    });

    _statusTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      _checkStatus();
    });
  }

  @override
  void dispose() {
    _countdownTimer.cancel();
    _statusTimer.cancel();
    super.dispose();
  }

  void _addLog(String msg) {
    if (!mounted) return;
    final time = TimeOfDay.now();
    final ts =
        '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
    setState(() => _logs.add('[$ts] $msg'));
  }

  Future<void> _checkStatus() async {
    try {
      _addLog('Mengecek status pembayaran...');
      final result = await widget.api.getHelperStatus(widget.invoiceId);
      final status = result['status'] as String? ?? '';
      if (status == 'paid' || status == 'completed') {
        _addLog('Pembayaran diterima!');
        _countdownTimer.cancel();
        _statusTimer.cancel();
        await widget.api.completeHelper(widget.invoiceId, widget.username);
        _addLog('Cache berhasil di-clear.');
        await Future.delayed(const Duration(milliseconds: 500));
        widget.onSuccess();
      } else {
        _addLog('Status: $status - menunggu...');
      }
    } catch (e) {
      _addLog('Error: $e');
    }
  }

  String get _formattedTime {
    final m = (_remainingSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (_remainingSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: BoxDecoration(
        color: AppTheme.bgDeep,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: AppTheme.glassBorder2),
      ),
      child: Column(
        children: [
          const SizedBox(height: 12),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppTheme.textMuted.withOpacity(0.4),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'PEMBAYARAN QRIS',
            style: GoogleFonts.spaceMono(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Rp 5.000',
            style: GoogleFonts.rajdhani(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              color: AppTheme.fuchsia,
            ),
          ),
          const SizedBox(height: 16),

          // QR Code
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: widget.qrUrl.isNotEmpty
                ? QrImageView(
                    data: widget.qrUrl,
                    version: QrVersions.auto,
                    size: 200,
                  )
                : const SizedBox(
                    width: 200,
                    height: 200,
                    child: Center(
                      child: Text('QR tidak tersedia',
                          style: TextStyle(color: Colors.black54)),
                    ),
                  ),
          ),
          const SizedBox(height: 16),

          // Countdown
          Text(
            _formattedTime,
            style: GoogleFonts.spaceMono(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: _remainingSeconds <= 60 ? AppTheme.red : AppTheme.violet,
              letterSpacing: 4,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'SISA WAKTU',
            style: GoogleFonts.spaceMono(
              fontSize: 9,
              color: AppTheme.textMuted,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 16),

          // Activity log
          Expanded(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.bgDeepest.withOpacity(0.6),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.glassBorder),
              ),
              child: ListView.builder(
                itemCount: _logs.length,
                itemBuilder: (_, i) => Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    _logs[i],
                    style: GoogleFonts.spaceMono(
                      fontSize: 9,
                      color: AppTheme.textMuted,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Cancel button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: widget.onCancel,
                child: Text(
                  'BATALKAN',
                  style: GoogleFonts.spaceMono(
                    fontSize: 11,
                    color: AppTheme.red,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
