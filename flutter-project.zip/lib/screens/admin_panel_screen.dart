import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import 'package:genetic_app/theme/app_theme.dart';
import 'package:genetic_app/services/api_service.dart';
import 'package:genetic_app/services/auth_service.dart';
import 'package:genetic_app/widgets/glass_card.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  int _tabIndex = 0;
  bool _loading = true;

  // User info
  String _myRole = '';
  String _myUsername = '';

  // Create form
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _obscurePassword = true;
  String _selectedRole = 'member';
  String _selectedTrialLabel = '7d';
  int _selectedTrialDuration = 7 * 24 * 60; // minutes
  bool _creating = false;

  // Account list
  List<Map<String, dynamic>> _accounts = [];
  String _searchQuery = '';
  bool _loadingAccounts = false;
  Map<String, int> _roleCounts = {};

  late ApiService _api;

  // Role hierarchy
  static const _roleHierarchy = {
    'developer': ['owner', 'reseller', 'vip', 'member'],
    'owner': ['reseller', 'member'],
    'reseller': ['member'],
  };

  static const _roleOptions = [
    {'label': 'Member', 'value': 'member', 'color': 'green'},
    {'label': 'Reseller', 'value': 'reseller', 'color': 'purple'},
    {'label': 'VIP', 'value': 'vip', 'color': 'pink'},
    {'label': 'Owner', 'value': 'owner', 'color': 'amber'},
    {'label': 'Developer', 'value': 'developer', 'color': 'purple'},
  ];

  static const _trialOptions = [
    {'label': '3m', 'minutes': 3},
    {'label': '5m', 'minutes': 5},
    {'label': '10m', 'minutes': 10},
    {'label': '3d', 'minutes': 3 * 24 * 60},
    {'label': '7d', 'minutes': 7 * 24 * 60},
    {'label': '30d', 'minutes': 30 * 24 * 60},
    {'label': 'permanent', 'minutes': -1},
  ];

  @override
  void initState() {
    super.initState();
    _api = context.read<AuthService>().api;
    _loadUserInfo();
  }

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadUserInfo() async {
    try {
      final result = await _api.getMe();
      if (result['success'] == true && result['user'] != null) {
        final user = result['user'] as Map<String, dynamic>;
        setState(() {
          _myRole = (user['role'] as String? ?? '').toLowerCase();
          _myUsername = user['username'] as String? ?? '';
          _loading = false;
        });
        _loadAccounts();
      } else {
        setState(() => _loading = false);
      }
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  Future<void> _loadAccounts() async {
    setState(() => _loadingAccounts = true);
    try {
      final result = await _api.getAdminAccounts();
      if (result['success'] == true && result['accounts'] != null) {
        final list = (result['accounts'] as List)
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
        final counts = <String, int>{};
        for (final acc in list) {
          final role = (acc['role'] as String? ?? 'unknown').toLowerCase();
          counts[role] = (counts[role] ?? 0) + 1;
        }
        setState(() {
          _accounts = list;
          _roleCounts = counts;
        });
      }
    } catch (_) {}
    setState(() => _loadingAccounts = false);
  }

  bool get _hasCreatePermission {
    return _roleHierarchy.containsKey(_myRole);
  }

  List<Map<String, dynamic>> get _allowedRoles {
    final allowed = _roleHierarchy[_myRole] ?? [];
    return _roleOptions
        .where((r) => allowed.contains(r['value']))
        .toList();
  }

  List<Map<String, dynamic>> get _filteredAccounts {
    if (_searchQuery.isEmpty) return _accounts;
    final q = _searchQuery.toLowerCase();
    return _accounts.where((acc) {
      final name = (acc['username'] as String? ?? '').toLowerCase();
      final role = (acc['role'] as String? ?? '').toLowerCase();
      return name.contains(q) || role.contains(q);
    }).toList();
  }

  bool _canDeleteAccount(Map<String, dynamic> account) {
    final accRole = (account['role'] as String? ?? '').toLowerCase();
    final allowed = _roleHierarchy[_myRole] ?? [];
    return allowed.contains(accRole);
  }

  Future<void> _createAccount() async {
    final username = _usernameCtrl.text.trim();
    final password = _passwordCtrl.text.trim();
    if (username.isEmpty || password.isEmpty) {
      _showSnackBar('Username dan password harus diisi', isError: true);
      return;
    }

    setState(() => _creating = true);
    try {
      final result = await _api.createAccount(
        username,
        password,
        _selectedRole,
        _selectedTrialDuration,
      );
      if (result['success'] == true) {
        _showSnackBar('Akun berhasil dibuat');
        _usernameCtrl.clear();
        _passwordCtrl.clear();
        _loadAccounts();
      } else {
        _showSnackBar(result['message'] ?? 'Gagal membuat akun', isError: true);
      }
    } catch (e) {
      _showSnackBar('Error: $e', isError: true);
    }
    setState(() => _creating = false);
  }

  Future<void> _deleteAccount(String username) async {
    final confirmed = await _showConfirmDialog(
      'Hapus Akun',
      'Yakin ingin menghapus akun "$username"?',
    );
    if (confirmed != true) return;

    try {
      final result = await _api.deleteAccount(username);
      if (result['success'] == true) {
        _showSnackBar('Akun berhasil dihapus');
        _loadAccounts();
      } else {
        _showSnackBar(result['message'] ?? 'Gagal menghapus', isError: true);
      }
    } catch (e) {
      _showSnackBar('Error: $e', isError: true);
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: GoogleFonts.outfit(fontSize: 13)),
        backgroundColor: isError ? AppTheme.red.withOpacity(0.9) : AppTheme.green.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Future<bool?> _showConfirmDialog(String title, String message) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.bgDeep,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: AppTheme.glassBorder2),
        ),
        title: Text(
          title,
          style: GoogleFonts.rajdhani(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: AppTheme.textPrimary,
          ),
        ),
        content: Text(
          message,
          style: GoogleFonts.outfit(
            fontSize: 14,
            color: AppTheme.textSecondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('BATAL',
                style: GoogleFonts.spaceMono(
                    fontSize: 11, color: AppTheme.textMuted, letterSpacing: 1.5)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('HAPUS',
                style: GoogleFonts.spaceMono(
                    fontSize: 11, color: AppTheme.red, letterSpacing: 1.5)),
          ),
        ],
      ),
    );
  }

  void _showRolePicker() {
    final roles = _allowedRoles;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: BoxDecoration(
          color: AppTheme.bgDeep,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: AppTheme.glassBorder2),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.textMuted.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'PILIH ROLE',
              style: GoogleFonts.spaceMono(
                fontSize: 11,
                color: AppTheme.textMuted,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            ...roles.map((r) {
              final value = r['value'] as String;
              final label = r['label'] as String;
              final isSelected = _selectedRole == value;
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: InkWell(
                  onTap: () {
                    setState(() => _selectedRole = value);
                    Navigator.pop(ctx);
                  },
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppTheme.roleColor(value).withOpacity(0.12)
                          : AppTheme.bgMid.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected
                            ? AppTheme.roleColor(value).withOpacity(0.5)
                            : AppTheme.glassBorder,
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppTheme.roleColor(value),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          label,
                          style: GoogleFonts.rajdhani(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        const Spacer(),
                        if (isSelected)
                          Icon(Icons.check_rounded,
                              color: AppTheme.roleColor(value), size: 20),
                      ],
                    ),
                  ),
                ),
              );
            }),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showTrialPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: BoxDecoration(
          color: AppTheme.bgDeep,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: AppTheme.glassBorder2),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.textMuted.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'DURASI TRIAL',
              style: GoogleFonts.spaceMono(
                fontSize: 11,
                color: AppTheme.textMuted,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: _trialOptions.map((opt) {
                final label = opt['label'] as String;
                final minutes = opt['minutes'] as int;
                final isSelected = _selectedTrialLabel == label;
                return InkWell(
                  onTap: () {
                    setState(() {
                      _selectedTrialLabel = label;
                      _selectedTrialDuration = minutes;
                    });
                    Navigator.pop(ctx);
                  },
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 18, vertical: 12),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppTheme.violet.withOpacity(0.15)
                          : AppTheme.bgMid.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected
                            ? AppTheme.violet.withOpacity(0.5)
                            : AppTheme.glassBorder,
                      ),
                    ),
                    child: Text(
                      label,
                      style: GoogleFonts.spaceMono(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: isSelected
                            ? AppTheme.violetLight
                            : AppTheme.textSecondary,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDeepest,
      appBar: AppBar(
        backgroundColor: AppTheme.bgDeepest.withOpacity(0.9),
        elevation: 0,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu_rounded, color: AppTheme.violetLight),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: RichText(
          text: TextSpan(
            style: const TextStyle(
              fontFamily: 'Genetic',
              fontSize: 18,
              fontWeight: FontWeight.w700,
              letterSpacing: 3,
            ),
            children: const [
              TextSpan(text: 'ADMIN', style: TextStyle(color: AppTheme.textPrimary)),
              TextSpan(text: 'PANEL', style: TextStyle(color: AppTheme.fuchsia)),
            ],
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_rounded, color: AppTheme.red, size: 20),
            onPressed: () {
              context.read<AuthService>().logout(context);
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: AppTheme.violet),
            )
          : _tabIndex == 0
              ? _buildCreateTab()
              : _buildAccountListTab(),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppTheme.bgDeepest.withOpacity(0.97),
          border: Border(
            top: BorderSide(color: AppTheme.glassBorder),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _tabIndex,
          onTap: (i) => setState(() => _tabIndex = i),
          backgroundColor: Colors.transparent,
          elevation: 0,
          selectedItemColor: AppTheme.violet,
          unselectedItemColor: AppTheme.textMuted,
          selectedLabelStyle:
              GoogleFonts.spaceMono(fontSize: 9, letterSpacing: 1.5),
          unselectedLabelStyle:
              GoogleFonts.spaceMono(fontSize: 9, letterSpacing: 1.5),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.add_circle_outline_rounded),
              activeIcon: Icon(Icons.add_circle_rounded),
              label: 'BUAT',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.people_outline_rounded),
              activeIcon: Icon(Icons.people_rounded),
              label: 'AKUN',
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Create Tab
  // ---------------------------------------------------------------------------

  Widget _buildCreateTab() {
    if (!_hasCreatePermission) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: GlassCard(
            showShimmer: true,
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock_rounded,
                    size: 48, color: AppTheme.red.withOpacity(0.7)),
                const SizedBox(height: 16),
                Text(
                  'AKSES DITOLAK',
                  style: GoogleFonts.spaceMono(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.red,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Role "$_myRole" tidak memiliki izin untuk membuat akun.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.outfit(
                    fontSize: 13,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: GlassCard(
        showShimmer: true,
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'BUAT AKUN BARU',
              style: GoogleFonts.spaceMono(
                fontSize: 11,
                color: AppTheme.textMuted,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 20),

            // Username
            TextField(
              controller: _usernameCtrl,
              style: GoogleFonts.outfit(
                  fontSize: 14, color: AppTheme.textPrimary),
              decoration: InputDecoration(
                labelText: 'USERNAME',
                prefixIcon: const Icon(Icons.person_outline_rounded,
                    color: AppTheme.textMuted, size: 20),
              ),
            ),
            const SizedBox(height: 14),

            // Password
            TextField(
              controller: _passwordCtrl,
              obscureText: _obscurePassword,
              style: GoogleFonts.outfit(
                  fontSize: 14, color: AppTheme.textPrimary),
              decoration: InputDecoration(
                labelText: 'PASSWORD',
                prefixIcon: const Icon(Icons.lock_outline_rounded,
                    color: AppTheme.textMuted, size: 20),
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_off_rounded
                        : Icons.visibility_rounded,
                    color: AppTheme.textMuted,
                    size: 20,
                  ),
                  onPressed: () =>
                      setState(() => _obscurePassword = !_obscurePassword),
                ),
              ),
            ),
            const SizedBox(height: 14),

            // Role picker
            InkWell(
              onTap: _showRolePicker,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                decoration: BoxDecoration(
                  color: AppTheme.violet.withOpacity(0.03),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: AppTheme.violet.withOpacity(0.1)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppTheme.roleColor(_selectedRole),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'ROLE',
                      style: GoogleFonts.spaceMono(
                        fontSize: 9,
                        color: AppTheme.textMuted,
                        letterSpacing: 2,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      _selectedRole.toUpperCase(),
                      style: GoogleFonts.rajdhani(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.roleColor(_selectedRole),
                      ),
                    ),
                    const SizedBox(width: 4),
                    Icon(Icons.chevron_right_rounded,
                        color: AppTheme.textMuted, size: 20),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),

            // Trial picker
            InkWell(
              onTap: _showTrialPicker,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                decoration: BoxDecoration(
                  color: AppTheme.violet.withOpacity(0.03),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: AppTheme.violet.withOpacity(0.1)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.timer_outlined,
                        color: AppTheme.textMuted, size: 20),
                    const SizedBox(width: 12),
                    Text(
                      'TRIAL',
                      style: GoogleFonts.spaceMono(
                        fontSize: 9,
                        color: AppTheme.textMuted,
                        letterSpacing: 2,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      _selectedTrialLabel.toUpperCase(),
                      style: GoogleFonts.rajdhani(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.violetLight,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Icon(Icons.chevron_right_rounded,
                        color: AppTheme.textMuted, size: 20),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Create button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _creating ? null : _createAccount,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.violet.withOpacity(0.16),
                  foregroundColor: AppTheme.violetLight,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(13)),
                  side: BorderSide(color: AppTheme.violet.withOpacity(0.3)),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: _creating
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: AppTheme.violetLight,
                          strokeWidth: 2,
                        ),
                      )
                    : Text(
                        'BUAT AKUN',
                        style: GoogleFonts.outfit(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2.5,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Account List Tab
  // ---------------------------------------------------------------------------

  Widget _buildAccountListTab() {
    final filtered = _filteredAccounts;

    return RefreshIndicator(
      onRefresh: _loadAccounts,
      color: AppTheme.violet,
      backgroundColor: AppTheme.bgDeep,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Stats row
          _buildStatsRow(),
          const SizedBox(height: 16),

          // Search field
          TextField(
            onChanged: (v) => setState(() => _searchQuery = v),
            style:
                GoogleFonts.outfit(fontSize: 14, color: AppTheme.textPrimary),
            decoration: InputDecoration(
              hintText: 'Cari akun...',
              prefixIcon: const Icon(Icons.search_rounded,
                  color: AppTheme.textMuted, size: 20),
            ),
          ),
          const SizedBox(height: 16),

          if (_loadingAccounts)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: CircularProgressIndicator(color: AppTheme.violet),
              ),
            )
          else if (filtered.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Text(
                  'Tidak ada akun ditemukan',
                  style: GoogleFonts.outfit(
                      fontSize: 13, color: AppTheme.textMuted),
                ),
              ),
            )
          else
            ...filtered.map((acc) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _buildAccountCard(acc),
                )),
        ],
      ),
    );
  }

  Widget _buildStatsRow() {
    final stats = <String, Color>{
      'member': AppTheme.green,
      'reseller': AppTheme.violet,
      'vip': AppTheme.pink,
      'owner': AppTheme.amber,
      'developer': AppTheme.purple,
    };

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: stats.entries.map((e) {
          final count = _roleCounts[e.key] ?? 0;
          return Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: e.value.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: e.value.withOpacity(0.2)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: e.value,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  '$count',
                  style: GoogleFonts.spaceMono(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: e.value,
                  ),
                ),
                const SizedBox(width: 4),
                Text(
                  e.key.toUpperCase(),
                  style: GoogleFonts.spaceMono(
                    fontSize: 8,
                    color: e.value.withOpacity(0.7),
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildAccountCard(Map<String, dynamic> account) {
    final username = account['username'] as String? ?? '';
    final role = (account['role'] as String? ?? '').toLowerCase();
    final createdBy = account['createdBy'] as String? ?? '-';
    final trialExpiry = account['trialExpiry'];
    final initial = username.isNotEmpty ? username[0].toUpperCase() : '?';

    // Trial badge
    String trialLabel;
    Color trialColor;
    if (trialExpiry == null || trialExpiry == -1 || trialExpiry == 'permanent') {
      trialLabel = 'PERMANENT';
      trialColor = AppTheme.violet;
    } else {
      final expiry = DateTime.tryParse(trialExpiry.toString());
      if (expiry != null && expiry.isAfter(DateTime.now())) {
        trialLabel = 'ACTIVE';
        trialColor = AppTheme.green;
      } else {
        trialLabel = 'EXPIRED';
        trialColor = AppTheme.red;
      }
    }

    final canDelete = _canDeleteAccount(account);

    return GlassCard(
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          // Avatar
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [
                  AppTheme.roleColor(role).withOpacity(0.3),
                  AppTheme.roleColor(role).withOpacity(0.1),
                ],
              ),
              border: Border.all(
                  color: AppTheme.roleColor(role).withOpacity(0.4)),
            ),
            child: Center(
              child: Text(
                initial,
                style: GoogleFonts.rajdhani(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.roleColor(role),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),

          // Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  username,
                  style: GoogleFonts.rajdhani(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'by $createdBy',
                  style: GoogleFonts.spaceMono(
                    fontSize: 9,
                    color: AppTheme.textMuted,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    // Role badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: AppTheme.roleColor(role).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                            color:
                                AppTheme.roleColor(role).withOpacity(0.3)),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: GoogleFonts.spaceMono(
                          fontSize: 8,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.roleColor(role),
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    // Trial badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: trialColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(6),
                        border:
                            Border.all(color: trialColor.withOpacity(0.3)),
                      ),
                      child: Text(
                        trialLabel,
                        style: GoogleFonts.spaceMono(
                          fontSize: 8,
                          fontWeight: FontWeight.w700,
                          color: trialColor,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Delete button
          if (canDelete)
            IconButton(
              icon: Icon(Icons.delete_outline_rounded,
                  color: AppTheme.red.withOpacity(0.6), size: 20),
              onPressed: () => _deleteAccount(username),
            ),
        ],
      ),
    );
  }
}
