import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:genetic_app/theme/app_theme.dart';

class AboutScreen extends StatefulWidget {
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _orbitController;

  @override
  void initState() {
    super.initState();
    _orbitController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();
  }

  @override
  void dispose() {
    _orbitController.dispose();
    super.dispose();
  }

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDeepest,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const SizedBox(height: 30),
                    _buildHeroSection(),
                    const SizedBox(height: 30),
                    _buildTitleSection(),
                    const SizedBox(height: 30),
                    _buildDeveloperCard(),
                    const SizedBox(height: 24),
                    _buildSocialRow(),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.bgDeepest,
        border: Border(
          bottom: BorderSide(color: AppTheme.glassBorder, width: 1),
        ),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new,
                size: 18, color: AppTheme.violetLight),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(width: 4),
          RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: 'ABOUT',
                  style: TextStyle(
                    fontFamily: 'Genetic',
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                    letterSpacing: 3,
                  ),
                ),
                TextSpan(
                  text: 'US',
                  style: TextStyle(
                    fontFamily: 'Genetic',
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.fuchsia,
                    letterSpacing: 3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroSection() {
    return SizedBox(
      width: 140,
      height: 140,
      child: AnimatedBuilder(
        animation: _orbitController,
        builder: (context, child) {
          return Stack(
            alignment: Alignment.center,
            children: [
              // Orbiting ring 1
              Transform.rotate(
                angle: _orbitController.value * 2 * math.pi,
                child: Container(
                  width: 130,
                  height: 130,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppTheme.violet.withOpacity(0.15),
                      width: 1,
                    ),
                  ),
                ),
              ),
              // Orbiting ring 2
              Transform.rotate(
                angle: -_orbitController.value * 2 * math.pi + math.pi / 3,
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppTheme.fuchsia.withOpacity(0.1),
                      width: 1,
                    ),
                  ),
                ),
              ),
              // Orbiting dot 1
              Transform.rotate(
                angle: _orbitController.value * 2 * math.pi,
                child: Transform.translate(
                  offset: const Offset(65, 0),
                  child: Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppTheme.violet,
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.violet.withOpacity(0.6),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              // Orbiting dot 2
              Transform.rotate(
                angle: -_orbitController.value * 2 * math.pi + math.pi,
                child: Transform.translate(
                  offset: const Offset(55, 0),
                  child: Container(
                    width: 4,
                    height: 4,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppTheme.fuchsia,
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.fuchsia.withOpacity(0.6),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              // Center icon
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppTheme.violet.withOpacity(0.25),
                      AppTheme.fuchsia.withOpacity(0.1),
                    ],
                  ),
                  border: Border.all(color: AppTheme.glassBorder2),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.violet.withOpacity(0.15),
                      blurRadius: 20,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.code,
                  color: AppTheme.violetLight,
                  size: 30,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildTitleSection() {
    return Column(
      children: [
        Text(
          'GENETIC',
          style: TextStyle(
            fontFamily: 'Genetic',
            fontSize: 36,
            fontWeight: FontWeight.w700,
            color: AppTheme.textPrimary,
            letterSpacing: 8,
            shadows: [
              Shadow(
                color: AppTheme.violet.withOpacity(0.5),
                blurRadius: 20,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        // Version badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: AppTheme.green.withOpacity(0.08),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppTheme.green.withOpacity(0.2)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.green,
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.green.withOpacity(0.5),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'VERSION 3.0.0',
                style: GoogleFonts.spaceMono(
                  fontSize: 10,
                  letterSpacing: 2,
                  color: AppTheme.green,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDeveloperCard() {
    return Container(
      decoration: AppTheme.glassCard,
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // Avatar
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [
                  AppTheme.violet.withOpacity(0.3),
                  AppTheme.fuchsia.withOpacity(0.15),
                ],
              ),
              border: Border.all(color: AppTheme.glassBorder2),
            ),
            child: Center(
              child: Text(
                'S',
                style: GoogleFonts.rajdhani(
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.violetLight,
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),

          // Name
          Text(
            'Smooth UK',
            style: GoogleFonts.rajdhani(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 4),

          // Subtitle
          Text(
            'Developer & Modding',
            style: GoogleFonts.outfit(
              fontSize: 12,
              color: AppTheme.textSecondary,
            ),
          ),
          const SizedBox(height: 12),

          // Verify badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            decoration: BoxDecoration(
              color: AppTheme.violet.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppTheme.violet.withOpacity(0.25)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.verified,
                    color: AppTheme.violetLight, size: 14),
                const SizedBox(width: 6),
                Text(
                  'VERIFY',
                  style: GoogleFonts.spaceMono(
                    fontSize: 9,
                    letterSpacing: 2,
                    color: AppTheme.violetLight,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSocialRow() {
    return Row(
      children: [
        Expanded(
          child: InkWell(
            onTap: () => _launchUrl('https://t.me/ZenithIIX'),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: AppTheme.telegramBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border:
                    Border.all(color: AppTheme.telegramBlue.withOpacity(0.25)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.send, color: AppTheme.telegramBlue, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    'Telegram',
                    style: GoogleFonts.spaceMono(
                      fontSize: 10,
                      letterSpacing: 1,
                      color: AppTheme.telegramBlue,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: InkWell(
            onTap: () => _launchUrl('https://tiktok.com/@yudzx_01'),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: AppTheme.tiktokRed.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border:
                    Border.all(color: AppTheme.tiktokRed.withOpacity(0.25)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.music_note, color: AppTheme.tiktokRed, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    'TikTok',
                    style: GoogleFonts.spaceMono(
                      fontSize: 10,
                      letterSpacing: 1,
                      color: AppTheme.tiktokRed,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
