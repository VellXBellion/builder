import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:genetic_app/theme/app_theme.dart';
import 'package:genetic_app/services/auth_service.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  int _countdown = 10;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..forward();

    // Initialize auth service to load stored token
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AuthService>().init();
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      setState(() {
        _countdown--;
      });
      if (_countdown <= 0) {
        timer.cancel();
        _navigate();
      }
    });
  }

  void _navigate() {
    if (!mounted) return;
    final auth = context.read<AuthService>();
    if (auth.token != null && auth.token!.isNotEmpty) {
      Navigator.of(context).pushReplacementNamed('/home');
    } else {
      Navigator.of(context).pushReplacementNamed('/login');
    }
  }

  void _skip() {
    _timer?.cancel();
    _controller.stop();
    _navigate();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDeepest,
      body: Stack(
        children: [
          // Background gradient
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center,
                radius: 0.8,
                colors: [
                  AppTheme.violet.withOpacity(0.08),
                  AppTheme.bgDeepest,
                ],
              ),
            ),
          ),

          // Skip button
          Positioned(
            top: MediaQuery.of(context).padding.top + 12,
            right: 16,
            child: TextButton(
              onPressed: _skip,
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.textMuted,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(color: AppTheme.glassBorder),
                ),
              ),
              child: Text(
                'LEWATI',
                style: GoogleFonts.spaceMono(
                  fontSize: 10,
                  letterSpacing: 2,
                  color: AppTheme.textMuted,
                ),
              ),
            ),
          ),

          // Center content
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // GENETIC title with glow
                Text(
                  'GENETIC',
                  style: TextStyle(
                    fontFamily: 'Genetic',
                    fontSize: 52,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                    letterSpacing: 12,
                    shadows: [
                      Shadow(
                        color: AppTheme.violet.withOpacity(0.6),
                        blurRadius: 30,
                      ),
                      Shadow(
                        color: AppTheme.fuchsia.withOpacity(0.3),
                        blurRadius: 60,
                      ),
                      Shadow(
                        color: AppTheme.violet.withOpacity(0.4),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // Subtitle
                Text(
                  'SMOOTHING  -  REVERSE',
                  style: GoogleFonts.spaceMono(
                    fontSize: 10,
                    letterSpacing: 4,
                    color: AppTheme.textMuted,
                  ),
                ),

                const SizedBox(height: 60),

                // Countdown ring
                SizedBox(
                  width: 80,
                  height: 80,
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      return Stack(
                        alignment: Alignment.center,
                        children: [
                          // Ring background
                          SizedBox(
                            width: 80,
                            height: 80,
                            child: CircularProgressIndicator(
                              value: 1.0,
                              strokeWidth: 2,
                              color: AppTheme.violet.withOpacity(0.15),
                            ),
                          ),
                          // Ring progress
                          SizedBox(
                            width: 80,
                            height: 80,
                            child: CircularProgressIndicator(
                              value: _controller.value,
                              strokeWidth: 2.5,
                              color: AppTheme.violet,
                              strokeCap: StrokeCap.round,
                            ),
                          ),
                          // Countdown number
                          Text(
                            '$_countdown',
                            style: GoogleFonts.rajdhani(
                              fontSize: 28,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.textPrimary,
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
