import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:genetic_app/theme/app_theme.dart';
import 'package:genetic_app/services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  bool _rememberMe = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadSavedCredentials();
  }

  Future<void> _loadSavedCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('saved_credentials');
    if (saved != null) {
      try {
        final decoded = utf8.decode(base64Decode(saved));
        final parts = decoded.split(':');
        if (parts.length == 2) {
          _usernameController.text = parts[0];
          _passwordController.text = parts[1];
          setState(() => _rememberMe = true);
        }
      } catch (_) {}
    }
  }

  Future<void> _saveCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    if (_rememberMe) {
      final raw = '${_usernameController.text}:${_passwordController.text}';
      final encoded = base64Encode(utf8.encode(raw));
      await prefs.setString('saved_credentials', encoded);
    } else {
      await prefs.remove('saved_credentials');
    }
  }

  void _showToast(String message, {bool isError = true}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).removeCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: isError ? AppTheme.red : AppTheme.green,
              size: 18,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: GoogleFonts.outfit(
                  fontSize: 13,
                  color: AppTheme.textPrimary,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.bgMid,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: isError
                ? AppTheme.red.withOpacity(0.3)
                : AppTheme.green.withOpacity(0.3),
          ),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> _login() async {
    final username = _usernameController.text.trim();
    final password = _passwordController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showToast('Username dan password wajib diisi');
      return;
    }

    setState(() => _isLoading = true);

    try {
      final auth = context.read<AuthService>();
      final result = await auth.login(username, password);

      if (!mounted) return;

      if (result['success'] == true) {
        await _saveCredentials();
        _showToast('Login berhasil!', isError: false);
        await Future.delayed(const Duration(milliseconds: 500));
        if (mounted) {
          Navigator.of(context).pushReplacementNamed('/home');
        }
      } else {
        _showToast(result['message'] ?? 'Login gagal');
      }
    } catch (e) {
      _showToast('Koneksi gagal: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDeepest,
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Banner area
            _buildBanner(),

            // Login card
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: _buildLoginCard(),
            ),

            const SizedBox(height: 30),

            // Social row
            _buildSocialRow(),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildBanner() {
    return Container(
      width: double.infinity,
      height: 220,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            AppTheme.bgLight,
            AppTheme.bgDeep.withOpacity(0.8),
            AppTheme.bgDeepest,
          ],
        ),
      ),
      child: Stack(
        children: [
          // Placeholder image area
          Container(
            width: double.infinity,
            height: 220,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.violet.withOpacity(0.12),
                  AppTheme.fuchsia.withOpacity(0.06),
                  AppTheme.bgDeepest.withOpacity(0.95),
                ],
              ),
            ),
          ),
          // Gradient overlay
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  AppTheme.bgDeepest.withOpacity(0.5),
                  AppTheme.bgDeepest,
                ],
                stops: const [0.0, 0.6, 1.0],
              ),
            ),
          ),
          // WELCOMEBACK text
          Positioned(
            bottom: 20,
            left: 24,
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'WELCOME',
                    style: TextStyle(
                      fontFamily: 'Genetic',
                      fontSize: 32,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                      letterSpacing: 4,
                      shadows: [
                        Shadow(
                          color: Colors.black.withOpacity(0.5),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                  TextSpan(
                    text: 'BACK',
                    style: TextStyle(
                      fontFamily: 'Genetic',
                      fontSize: 32,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.violet,
                      letterSpacing: 4,
                      shadows: [
                        Shadow(
                          color: AppTheme.violet.withOpacity(0.5),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoginCard() {
    return Container(
      decoration: AppTheme.glassCard,
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title
          Text(
            'Masuk ke akun kamu',
            style: GoogleFonts.outfit(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              fontStyle: FontStyle.italic,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Secure  \u00b7  Encrypted  \u00b7  Private',
            style: GoogleFonts.spaceMono(
              fontSize: 9,
              letterSpacing: 2,
              color: AppTheme.textMuted,
            ),
          ),

          const SizedBox(height: 24),

          // Username
          TextField(
            controller: _usernameController,
            style: GoogleFonts.outfit(
              fontSize: 14,
              color: AppTheme.textPrimary,
            ),
            decoration: InputDecoration(
              labelText: 'USERNAME',
              prefixIcon: Icon(
                Icons.person_outline,
                color: AppTheme.textMuted,
                size: 20,
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Password
          TextField(
            controller: _passwordController,
            obscureText: _obscurePassword,
            style: GoogleFonts.outfit(
              fontSize: 14,
              color: AppTheme.textPrimary,
            ),
            decoration: InputDecoration(
              labelText: 'PASSWORD',
              prefixIcon: Icon(
                Icons.lock_outline,
                color: AppTheme.textMuted,
                size: 20,
              ),
              suffixIcon: IconButton(
                icon: Icon(
                  _obscurePassword
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: AppTheme.textMuted,
                  size: 20,
                ),
                onPressed: () =>
                    setState(() => _obscurePassword = !_obscurePassword),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Remember me + save
          Row(
            children: [
              SizedBox(
                height: 20,
                width: 20,
                child: Checkbox(
                  value: _rememberMe,
                  onChanged: (v) => setState(() => _rememberMe = v ?? false),
                  activeColor: AppTheme.violet,
                  side: BorderSide(color: AppTheme.glassBorder2),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'Ingat saya',
                style: GoogleFonts.outfit(
                  fontSize: 12,
                  color: AppTheme.textSecondary,
                ),
              ),
              const Spacer(),
              TextButton(
                onPressed: () async {
                  setState(() => _rememberMe = true);
                  await _saveCredentials();
                  if (mounted) {
                    _showToast('Akun disimpan', isError: false);
                  }
                },
                style: TextButton.styleFrom(
                  foregroundColor: AppTheme.violetLight,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                    side: BorderSide(color: AppTheme.glassBorder),
                  ),
                ),
                child: Text(
                  'SIMPAN',
                  style: GoogleFonts.spaceMono(
                    fontSize: 9,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Login button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _login,
              child: _isLoading
                  ? SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppTheme.violetLight,
                      ),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Masuk Sekarang',
                          style: GoogleFonts.outfit(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Icon(Icons.arrow_forward, size: 16),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSocialRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _socialButton(
          icon: Icons.send,
          label: 'Telegram',
          color: AppTheme.telegramBlue,
          onTap: () {
            // Launch t.me/ZenithIIX
          },
        ),
        const SizedBox(width: 12),
        _socialButton(
          icon: Icons.music_note,
          label: 'TikTok',
          color: AppTheme.tiktokRed,
          onTap: () {
            // Launch tiktok.com/@yudzx_01
          },
        ),
      ],
    );
  }

  Widget _socialButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: GoogleFonts.spaceMono(
                fontSize: 10,
                letterSpacing: 1,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
