import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:genetic_app/theme/app_theme.dart';
import 'package:genetic_app/services/auth_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _oldPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  bool _obscureOld = true;
  bool _obscureNew = true;
  bool _obscureConfirm = true;
  bool _isChangingPassword = false;

  @override
  void dispose() {
    _oldPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _showToast(String message, {bool isError = true}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).removeCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: isError ? AppTheme.red : AppTheme.green,
              size: 18,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: GoogleFonts.outfit(
                  fontSize: 13,
                  color: AppTheme.textPrimary,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.bgMid,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: isError
                ? AppTheme.red.withOpacity(0.3)
                : AppTheme.green.withOpacity(0.3),
          ),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> _changePassword() async {
    final oldPw = _oldPasswordController.text.trim();
    final newPw = _newPasswordController.text.trim();
    final confirmPw = _confirmPasswordController.text.trim();

    if (oldPw.isEmpty || newPw.isEmpty || confirmPw.isEmpty) {
      _showToast('Semua field harus diisi');
      return;
    }
    if (newPw != confirmPw) {
      _showToast('Password baru tidak cocok');
      return;
    }
    if (newPw.length < 4) {
      _showToast('Password minimal 4 karakter');
      return;
    }

    setState(() => _isChangingPassword = true);

    try {
      final auth = context.read<AuthService>();
      final result = await auth.api.changePassword(oldPw, newPw);

      if (!mounted) return;

      if (result['success'] == true) {
        _showToast('Password berhasil diubah!', isError: false);
        _oldPasswordController.clear();
        _newPasswordController.clear();
        _confirmPasswordController.clear();
      } else {
        _showToast(result['message'] ?? 'Gagal mengubah password');
      }
    } catch (e) {
      _showToast('Error: $e');
    } finally {
      if (mounted) setState(() => _isChangingPassword = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDeepest,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            _buildHeader(),

            // Content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ACCOUNT section
                    _sectionLabel('ACCOUNT'),
                    const SizedBox(height: 10),
                    _buildAccountInfo(),
                    const SizedBox(height: 12),
                    _buildChangePassword(),

                    const SizedBox(height: 24),

                    // APPLICATION section
                    _sectionLabel('APPLICATION'),
                    const SizedBox(height: 10),
                    _buildAboutLink(),

                    const SizedBox(height: 40),

                    // Logout button
                    _buildLogoutButton(),

                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.bgDeepest,
        border: Border(
          bottom: BorderSide(color: AppTheme.glassBorder, width: 1),
        ),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new,
                size: 18, color: AppTheme.violetLight),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(width: 4),
          Text(
            'SETTINGS',
            style: TextStyle(
              fontFamily: 'Genetic',
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
              letterSpacing: 3,
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(String label) {
    return Text(
      label,
      style: GoogleFonts.spaceMono(
        fontSize: 9,
        letterSpacing: 3,
        color: AppTheme.textMuted,
      ),
    );
  }

  Widget _buildAccountInfo() {
    final auth = context.watch<AuthService>();
    final user = auth.user;
    final username = user?.username ?? '-';
    final role = user?.role ?? '-';
    final uid = user?.uid ?? '-';

    return Container(
      decoration: AppTheme.glassCard,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Info Akun',
            style: GoogleFonts.rajdhani(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 16),
          _infoRow('Username', username),
          const SizedBox(height: 10),
          _infoRow('Role', role.toUpperCase()),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _infoRow('UID', uid)),
              IconButton(
                icon: const Icon(Icons.copy, size: 16, color: AppTheme.textMuted),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: uid));
                  _showToast('UID disalin!', isError: false);
                },
                constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                padding: EdgeInsets.zero,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 80,
          child: Text(
            label,
            style: GoogleFonts.spaceMono(
              fontSize: 9,
              letterSpacing: 1,
              color: AppTheme.textMuted,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: GoogleFonts.outfit(
              fontSize: 13,
              color: AppTheme.textPrimary,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildChangePassword() {
    return Container(
      decoration: AppTheme.glassCard,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ganti Password',
            style: GoogleFonts.rajdhani(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 16),

          TextField(
            controller: _oldPasswordController,
            obscureText: _obscureOld,
            style: GoogleFonts.outfit(fontSize: 14, color: AppTheme.textPrimary),
            decoration: InputDecoration(
              labelText: 'OLD PASSWORD',
              prefixIcon: const Icon(Icons.lock_outline,
                  color: AppTheme.textMuted, size: 18),
              suffixIcon: IconButton(
                icon: Icon(
                  _obscureOld
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: AppTheme.textMuted,
                  size: 18,
                ),
                onPressed: () => setState(() => _obscureOld = !_obscureOld),
              ),
            ),
          ),
          const SizedBox(height: 12),

          TextField(
            controller: _newPasswordController,
            obscureText: _obscureNew,
            style: GoogleFonts.outfit(fontSize: 14, color: AppTheme.textPrimary),
            decoration: InputDecoration(
              labelText: 'NEW PASSWORD',
              prefixIcon: const Icon(Icons.lock_outline,
                  color: AppTheme.textMuted, size: 18),
              suffixIcon: IconButton(
                icon: Icon(
                  _obscureNew
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: AppTheme.textMuted,
                  size: 18,
                ),
                onPressed: () => setState(() => _obscureNew = !_obscureNew),
              ),
            ),
          ),
          const SizedBox(height: 12),

          TextField(
            controller: _confirmPasswordController,
            obscureText: _obscureConfirm,
            style: GoogleFonts.outfit(fontSize: 14, color: AppTheme.textPrimary),
            decoration: InputDecoration(
              labelText: 'CONFIRM PASSWORD',
              prefixIcon: const Icon(Icons.lock_outline,
                  color: AppTheme.textMuted, size: 18),
              suffixIcon: IconButton(
                icon: Icon(
                  _obscureConfirm
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: AppTheme.textMuted,
                  size: 18,
                ),
                onPressed: () =>
                    setState(() => _obscureConfirm = !_obscureConfirm),
              ),
            ),
          ),
          const SizedBox(height: 20),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isChangingPassword ? null : _changePassword,
              child: _isChangingPassword
                  ? SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppTheme.violetLight,
                      ),
                    )
                  : Text(
                      'SIMPAN',
                      style: GoogleFonts.outfit(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 2,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAboutLink() {
    return InkWell(
      onTap: () => Navigator.pushNamed(context, '/about'),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: AppTheme.glassCardSubtle,
        child: Row(
          children: [
            const Icon(Icons.info_outline,
                color: AppTheme.violetLight, size: 20),
            const SizedBox(width: 12),
            Text(
              'About',
              style: GoogleFonts.outfit(
                fontSize: 14,
                color: AppTheme.textPrimary,
              ),
            ),
            const Spacer(),
            const Icon(Icons.chevron_right,
                color: AppTheme.textMuted, size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildLogoutButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () async {
          final auth = context.read<AuthService>();
          await auth.logout();
          if (mounted) {
            Navigator.of(context).pushReplacementNamed('/login');
          }
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: AppTheme.red.withOpacity(0.12),
          foregroundColor: AppTheme.red,
          side: BorderSide(color: AppTheme.red.withOpacity(0.3)),
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.logout, size: 18),
            const SizedBox(width: 8),
            Text(
              'LOGOUT',
              style: GoogleFonts.outfit(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 2,
                color: AppTheme.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
