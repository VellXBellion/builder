import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:genetic_app/theme/app_theme.dart';
import 'package:genetic_app/services/api_service.dart';
import 'package:genetic_app/widgets/glass_card.dart';

class OrderScreen extends StatefulWidget {
  const OrderScreen({super.key});

  @override
  State<OrderScreen> createState() => _OrderScreenState();
}

class _OrderScreenState extends State<OrderScreen> {
  final _api = ApiService();
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();

  String _selectedRole = '';
  bool _submitting = false;

  // Payment state
  bool _showSuccess = false;
  String _successUsername = '';
  String _successPassword = '';
  String _successRole = '';

  static const _products = [
    {
      'role': 'member',
      'label': 'Member',
      'price': 'Rp 50.000',
      'priceValue': 50000,
      'icon': Icons.person_rounded,
    },
    {
      'role': 'reseller',
      'label': 'Reseller',
      'price': 'Rp 250.000',
      'priceValue': 250000,
      'icon': Icons.store_rounded,
    },
    {
      'role': 'owner',
      'label': 'Owner',
      'price': 'Rp 500.000',
      'priceValue': 500000,
      'icon': Icons.diamond_rounded,
    },
  ];

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: GoogleFonts.outfit(fontSize: 13)),
        backgroundColor:
            isError ? AppTheme.red.withOpacity(0.9) : AppTheme.green.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Future<void> _submitOrder() async {
    final username = _usernameCtrl.text.trim();
    final password = _passwordCtrl.text.trim();

    if (_selectedRole.isEmpty) {
      _showSnackBar('Pilih paket terlebih dahulu', isError: true);
      return;
    }
    if (username.isEmpty) {
      _showSnackBar('Username harus diisi', isError: true);
      return;
    }
    if (password.isEmpty || password.length < 4) {
      _showSnackBar('Password minimal 4 karakter', isError: true);
      return;
    }

    setState(() => _submitting = true);
    try {
      final result = await _api.createOrder(_selectedRole, username, password);
      if (result['success'] == true) {
        final invoiceId = result['invoiceId'] as String? ?? '';
        final qrUrl = result['qrUrl'] as String? ?? '';
        if (mounted) {
          _showPaymentSheet(invoiceId, qrUrl, username, password, _selectedRole);
        }
      } else {
        _showSnackBar(result['message'] ?? 'Gagal membuat order', isError: true);
      }
    } catch (e) {
      _showSnackBar('Error: $e', isError: true);
    }
    setState(() => _submitting = false);
  }

  void _showPaymentSheet(String invoiceId, String qrUrl, String username,
      String password, String role) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _PaymentSheet(
        api: _api,
        invoiceId: invoiceId,
        qrUrl: qrUrl,
        username: username,
        password: password,
        role: role,
        onSuccess: () {
          Navigator.pop(ctx);
          setState(() {
            _showSuccess = true;
            _successUsername = username;
            _successPassword = password;
            _successRole = role;
          });
        },
        onCancel: () => Navigator.pop(ctx),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_showSuccess) return _buildSuccessView();

    return Scaffold(
      backgroundColor: AppTheme.bgDeepest,
      appBar: AppBar(
        backgroundColor: AppTheme.bgDeepest.withOpacity(0.9),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppTheme.violetLight),
          onPressed: () => Navigator.pop(context),
        ),
        title: RichText(
          text: TextSpan(
            style: const TextStyle(
              fontFamily: 'Genetic',
              fontSize: 18,
              fontWeight: FontWeight.w700,
              letterSpacing: 3,
            ),
            children: const [
              TextSpan(text: 'ORDER', style: TextStyle(color: AppTheme.textPrimary)),
              TextSpan(text: 'AKUN', style: TextStyle(color: AppTheme.fuchsia)),
            ],
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Product cards
            Text(
              'PILIH PAKET',
              style: GoogleFonts.spaceMono(
                fontSize: 10,
                color: AppTheme.textMuted,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            ..._products.map((p) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _buildProductCard(p),
                )),

            const SizedBox(height: 24),

            // Order form
            Text(
              'DATA AKUN',
              style: GoogleFonts.spaceMono(
                fontSize: 10,
                color: AppTheme.textMuted,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            GlassCard(
              showShimmer: true,
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  TextField(
                    controller: _usernameCtrl,
                    style: GoogleFonts.outfit(
                        fontSize: 14, color: AppTheme.textPrimary),
                    decoration: const InputDecoration(
                      labelText: 'USERNAME',
                      prefixIcon: Icon(Icons.person_outline_rounded,
                          color: AppTheme.textMuted, size: 20),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _passwordCtrl,
                    style: GoogleFonts.outfit(
                        fontSize: 14, color: AppTheme.textPrimary),
                    decoration: const InputDecoration(
                      labelText: 'PASSWORD',
                      prefixIcon: Icon(Icons.lock_outline_rounded,
                          color: AppTheme.textMuted, size: 20),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _submitting ? null : _submitOrder,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.violet.withOpacity(0.16),
                        foregroundColor: AppTheme.violetLight,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(13)),
                        side: BorderSide(
                            color: AppTheme.violet.withOpacity(0.3)),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      child: _submitting
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                color: AppTheme.violetLight,
                                strokeWidth: 2,
                              ),
                            )
                          : Text(
                              'BUAT AKUN',
                              style: GoogleFonts.outfit(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 2.5,
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductCard(Map<String, dynamic> product) {
    final role = product['role'] as String;
    final label = product['label'] as String;
    final price = product['price'] as String;
    final icon = product['icon'] as IconData;
    final isSelected = _selectedRole == role;
    final roleColor = AppTheme.roleColor(role);

    return GestureDetector(
      onTap: () => setState(() => _selectedRole = role),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isSelected
                ? [
                    roleColor.withOpacity(0.15),
                    AppTheme.bgMid.withOpacity(0.9),
                  ]
                : [
                    const Color(0xFF1A1040).withOpacity(0.85),
                    const Color(0xFF0E0A20).withOpacity(0.95),
                  ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected
                ? roleColor.withOpacity(0.6)
                : AppTheme.glassBorder2,
            width: isSelected ? 1.5 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
            if (isSelected)
              BoxShadow(
                color: roleColor.withOpacity(0.1),
                blurRadius: 20,
                spreadRadius: 2,
              ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    roleColor.withOpacity(0.25),
                    roleColor.withOpacity(0.08),
                  ],
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: roleColor, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: GoogleFonts.rajdhani(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  Text(
                    price,
                    style: GoogleFonts.spaceMono(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: roleColor,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isSelected
                    ? roleColor.withOpacity(0.2)
                    : Colors.transparent,
                border: Border.all(
                  color: isSelected ? roleColor : AppTheme.textMuted,
                  width: 2,
                ),
              ),
              child: isSelected
                  ? Icon(Icons.check_rounded, size: 14, color: roleColor)
                  : null,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSuccessView() {
    return Scaffold(
      backgroundColor: AppTheme.bgDeepest,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32),
          child: GlassCard(
            showShimmer: true,
            showGlow: true,
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppTheme.green.withOpacity(0.15),
                    border:
                        Border.all(color: AppTheme.green.withOpacity(0.4)),
                  ),
                  child: const Icon(Icons.check_rounded,
                      color: AppTheme.green, size: 32),
                ),
                const SizedBox(height: 20),
                Text(
                  'PEMBAYARAN BERHASIL',
                  style: GoogleFonts.spaceMono(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.green,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 24),
                _credentialRow('USERNAME', _successUsername),
                const SizedBox(height: 10),
                _credentialRow('PASSWORD', _successPassword),
                const SizedBox(height: 10),
                _credentialRow('ROLE', _successRole.toUpperCase()),
                const SizedBox(height: 24),
                Text(
                  'Kirim bukti pembayaran ke Telegram untuk aktivasi:',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.outfit(
                      fontSize: 13, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      final uri = Uri.parse('https://t.me/ZenithIIX');
                      if (await canLaunchUrl(uri)) {
                        await launchUrl(uri,
                            mode: LaunchMode.externalApplication);
                      }
                    },
                    icon: const Icon(Icons.send_rounded, size: 18),
                    label: Text(
                      'BUKA TELEGRAM',
                      style: GoogleFonts.outfit(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 2,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          AppTheme.telegramBlue.withOpacity(0.16),
                      foregroundColor: AppTheme.telegramBlue,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(13)),
                      side: BorderSide(
                          color: AppTheme.telegramBlue.withOpacity(0.3)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'KEMBALI',
                    style: GoogleFonts.spaceMono(
                      fontSize: 10,
                      color: AppTheme.textMuted,
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _credentialRow(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.bgMid.withOpacity(0.5),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.glassBorder),
      ),
      child: Row(
        children: [
          Text(
            label,
            style: GoogleFonts.spaceMono(
              fontSize: 9,
              color: AppTheme.textMuted,
              letterSpacing: 2,
            ),
          ),
          const Spacer(),
          Text(
            value,
            style: GoogleFonts.rajdhani(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// Payment Bottom Sheet
// =============================================================================

class _PaymentSheet extends StatefulWidget {
  final ApiService api;
  final String invoiceId;
  final String qrUrl;
  final String username;
  final String password;
  final String role;
  final VoidCallback onSuccess;
  final VoidCallback onCancel;

  const _PaymentSheet({
    required this.api,
    required this.invoiceId,
    required this.qrUrl,
    required this.username,
    required this.password,
    required this.role,
    required this.onSuccess,
    required this.onCancel,
  });

  @override
  State<_PaymentSheet> createState() => _PaymentSheetState();
}

class _PaymentSheetState extends State<_PaymentSheet> {
  late Timer _countdownTimer;
  late Timer _statusTimer;
  int _remainingSeconds = 5 * 60; // 5 minutes
  final List<String> _logs = [];

  @override
  void initState() {
    super.initState();
    _addLog('Menunggu pembayaran...');

    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_remainingSeconds <= 0) {
        _countdownTimer.cancel();
        _statusTimer.cancel();
        _addLog('Waktu habis. Pembayaran dibatalkan.');
        return;
      }
      setState(() => _remainingSeconds--);
    });

    _statusTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      _checkStatus();
    });
  }

  @override
  void dispose() {
    _countdownTimer.cancel();
    _statusTimer.cancel();
    super.dispose();
  }

  void _addLog(String msg) {
    if (!mounted) return;
    final time = TimeOfDay.now();
    final ts =
        '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
    setState(() => _logs.add('[$ts] $msg'));
  }

  Future<void> _checkStatus() async {
    try {
      _addLog('Mengecek status pembayaran...');
      final result = await widget.api.getOrderStatus(widget.invoiceId);
      final status = result['status'] as String? ?? '';
      if (status == 'paid' || status == 'completed') {
        _addLog('Pembayaran diterima!');
        _countdownTimer.cancel();
        _statusTimer.cancel();
        // Complete the order
        await widget.api.completeOrder(
          widget.invoiceId,
          widget.username,
          widget.password,
          widget.role,
        );
        _addLog('Akun berhasil dibuat.');
        await Future.delayed(const Duration(milliseconds: 500));
        widget.onSuccess();
      } else {
        _addLog('Status: $status - menunggu...');
      }
    } catch (e) {
      _addLog('Error: $e');
    }
  }

  String get _formattedTime {
    final m = (_remainingSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (_remainingSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: BoxDecoration(
        color: AppTheme.bgDeep,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: AppTheme.glassBorder2),
      ),
      child: Column(
        children: [
          const SizedBox(height: 12),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppTheme.textMuted.withOpacity(0.4),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'PEMBAYARAN QRIS',
            style: GoogleFonts.spaceMono(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 20),

          // QR Code
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: widget.qrUrl.isNotEmpty
                ? QrImageView(
                    data: widget.qrUrl,
                    version: QrVersions.auto,
                    size: 200,
                  )
                : const SizedBox(
                    width: 200,
                    height: 200,
                    child: Center(
                      child: Text('QR tidak tersedia',
                          style: TextStyle(color: Colors.black54)),
                    ),
                  ),
          ),
          const SizedBox(height: 16),

          // Countdown
          Text(
            _formattedTime,
            style: GoogleFonts.spaceMono(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: _remainingSeconds <= 60 ? AppTheme.red : AppTheme.violet,
              letterSpacing: 4,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'SISA WAKTU',
            style: GoogleFonts.spaceMono(
              fontSize: 9,
              color: AppTheme.textMuted,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 16),

          // Activity log
          Expanded(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.bgDeepest.withOpacity(0.6),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.glassBorder),
              ),
              child: ListView.builder(
                itemCount: _logs.length,
                itemBuilder: (_, i) => Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    _logs[i],
                    style: GoogleFonts.spaceMono(
                      fontSize: 9,
                      color: AppTheme.textMuted,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Cancel button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: widget.onCancel,
                child: Text(
                  'BATALKAN',
                  style: GoogleFonts.spaceMono(
                    fontSize: 11,
                    color: AppTheme.red,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
