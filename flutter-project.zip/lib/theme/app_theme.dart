import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // ── PURPLE CYBERPUNK PALETTE ──
  static const Color bgDeepest = Color(0xFF0A0618);
  static const Color bgDeep = Color(0xFF120B2E);
  static const Color bgMid = Color(0xFF1A1040);
  static const Color bgLight = Color(0xFF221752);
  static const Color bgLighter = Color(0xFF2A1E64);

  // Accents
  static const Color violet = Color(0xFFA855F7);
  static const Color violetLight = Color(0xFFC084FC);
  static const Color violetPale = Color(0xFFD8B4FE);
  static const Color violetFaint = Color(0xFFEDE9FE);
  static const Color fuchsia = Color(0xFFE879F9);
  static const Color fuchsiaDeep = Color(0xFFD946EF);

  // State
  static const Color green = Color(0xFF34D399);
  static const Color red = Color(0xFFFF4D6D);
  static const Color amber = Color(0xFFFFC34D);
  static const Color purple = Color(0xFFA78BFA);
  static const Color pink = Color(0xFFF472B6);

  // Text
  static const Color textPrimary = Color(0xFFF3E8FF);
  static const Color textSecondary = Color(0xFFC4B5FD);
  static const Color textMuted = Color(0xFF7C6AAC);
  static const Color textFaint = Color(0xFF2A1E64);

  // Glass / Borders
  static Color glassBg = Colors.white.withOpacity(0.03);
  static Color glassBorder = violet.withOpacity(0.15);
  static Color glassBorder2 = violet.withOpacity(0.25);
  static Color glassBorder3 = violet.withOpacity(0.40);
  static Color glowColor = violet.withOpacity(0.12);

  // Social
  static const Color telegramBlue = Color(0xFF0088CC);
  static const Color tiktokRed = Color(0xFFFE2C55);

  // Role colors
  static Color roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'developer': return purple;
      case 'owner': return amber;
      case 'reseller': return violet;
      case 'vip': return pink;
      case 'member': return green;
      default: return textMuted;
    }
  }

  // ── THEME DATA ──
  static ThemeData get darkPurple => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bgDeepest,
    colorScheme: const ColorScheme.dark(
      primary: violet,
      secondary: fuchsia,
      surface: bgDeep,
      error: red,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: bgDeepest.withOpacity(0.9),
      elevation: 0,
      centerTitle: true,
      titleTextStyle: const TextStyle(
        fontFamily: 'Genetic',
        fontSize: 18,
        fontWeight: FontWeight.w700,
        letterSpacing: 3,
        color: textPrimary,
      ),
      iconTheme: const IconThemeData(color: violetLight),
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: bgDeepest.withOpacity(0.97),
      selectedItemColor: violet,
      unselectedItemColor: textMuted,
      type: BottomNavigationBarType.fixed,
      selectedLabelStyle: GoogleFonts.spaceMono(fontSize: 9, letterSpacing: 1.5),
      unselectedLabelStyle: GoogleFonts.spaceMono(fontSize: 9, letterSpacing: 1.5),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: violet.withOpacity(0.03),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: violet.withOpacity(0.1)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: violet.withOpacity(0.1)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: violet.withOpacity(0.45), width: 1.5),
      ),
      hintStyle: TextStyle(color: textFaint, fontStyle: FontStyle.italic),
      labelStyle: GoogleFonts.spaceMono(
        fontSize: 9, color: textMuted, letterSpacing: 2,
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: violet.withOpacity(0.16),
        foregroundColor: violetLight,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
        side: BorderSide(color: violet.withOpacity(0.3)),
        padding: const EdgeInsets.symmetric(vertical: 16),
        textStyle: GoogleFonts.outfit(
          fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2.5,
        ),
      ),
    ),
    cardTheme: CardThemeData(
      color: bgDeep,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: glassBorder2),
      ),
      elevation: 0,
    ),
    textTheme: TextTheme(
      headlineLarge: const TextStyle(fontFamily: 'Genetic', fontSize: 28, fontWeight: FontWeight.w700, color: textPrimary, letterSpacing: 3),
      headlineMedium: GoogleFonts.rajdhani(fontSize: 20, fontWeight: FontWeight.w700, color: textPrimary, letterSpacing: 2),
      titleLarge: GoogleFonts.rajdhani(fontSize: 18, fontWeight: FontWeight.w700, color: textPrimary, letterSpacing: 1),
      titleMedium: GoogleFonts.outfit(fontSize: 15, fontWeight: FontWeight.w600, color: textPrimary),
      bodyLarge: GoogleFonts.outfit(fontSize: 14, color: textPrimary),
      bodyMedium: GoogleFonts.outfit(fontSize: 13, color: textSecondary),
      bodySmall: GoogleFonts.spaceMono(fontSize: 10, color: textMuted, letterSpacing: 1),
      labelSmall: GoogleFonts.spaceMono(fontSize: 8, color: textMuted, letterSpacing: 2),
    ),
  );

  // ── DECORATIONS ──
  static BoxDecoration get glassCard => BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        const Color(0xFF1A1040).withOpacity(0.85),
        const Color(0xFF0E0A20).withOpacity(0.95),
      ],
    ),
    borderRadius: BorderRadius.circular(20),
    border: Border.all(color: glassBorder2),
    boxShadow: [
      BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 24, offset: const Offset(0, 4)),
      BoxShadow(color: violet.withOpacity(0.06), blurRadius: 0, spreadRadius: 1),
    ],
  );

  static BoxDecoration get glassCardSubtle => BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        const Color(0xFF1A1040).withOpacity(0.8),
        const Color(0xFF120B2E).withOpacity(0.9),
      ],
    ),
    borderRadius: BorderRadius.circular(16),
    border: Border.all(color: glassBorder),
  );

  static List<BoxShadow> get neonGlow => [
    BoxShadow(color: violet.withOpacity(0.15), blurRadius: 20, spreadRadius: 2),
    BoxShadow(color: violet.withOpacity(0.06), blurRadius: 40, spreadRadius: 4),
  ];
}
