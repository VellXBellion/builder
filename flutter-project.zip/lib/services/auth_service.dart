import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:genetic_app/models/user_model.dart';
import 'package:genetic_app/services/api_service.dart';

class AuthService extends ChangeNotifier {
  final ApiService _api;

  bool _isLoggedIn = false;
  String? _token;
  String? _username;
  UserModel? _user;
  bool _initializing = true;

  AuthService({ApiService? apiService})
      : _api = apiService ?? ApiService();

  // ---------------------------------------------------------------------------
  // Getters
  // ---------------------------------------------------------------------------

  bool get isLoggedIn => _isLoggedIn;
  bool get isInitializing => _initializing;
  String? get token => _token;
  String? get username => _username;
  UserModel? get user => _user;
  ApiService get api => _api;

  // ---------------------------------------------------------------------------
  // Initialization
  // ---------------------------------------------------------------------------

  /// Call once at app start to restore session from SharedPreferences.
  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _token = prefs.getString('sync_token');
      _username = prefs.getString('username');

      if (_token != null && _token!.isNotEmpty) {
        _isLoggedIn = true;
        await loadUser();
      }
    } catch (e) {
      debugPrint('AuthService.init error: $e');
      _isLoggedIn = false;
      _token = null;
      _user = null;
    } finally {
      _initializing = false;
      notifyListeners();
    }
  }

  // ---------------------------------------------------------------------------
  // Auth actions
  // ---------------------------------------------------------------------------

  /// Authenticate with the server. Returns a result map with `success` key.
  Future<Map<String, dynamic>> login(
    String username,
    String password, {
    String deviceId = 'flutter_client',
  }) async {
    final result = await _api.login(username, password, deviceId);

    if (result['success'] == true) {
      _token = _api.token;
      _username = username;
      _isLoggedIn = true;

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('username', username);

      await loadUser();
      notifyListeners();
    }

    return result;
  }

  /// Log out, clear persisted session, and navigate to the login screen.
  Future<void> logout([BuildContext? context]) async {
    try {
      await _api.logout();
    } catch (_) {
      // Best-effort server logout; clear local state regardless.
    }

    _isLoggedIn = false;
    _token = null;
    _username = null;
    _user = null;

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('sync_token');
    await prefs.remove('username');

    notifyListeners();

    if (context != null && context.mounted) {
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (_) => false);
    }
  }

  // ---------------------------------------------------------------------------
  // User data
  // ---------------------------------------------------------------------------

  /// Fetch the authenticated user profile from /api/me.
  Future<void> loadUser() async {
    try {
      final result = await _api.getMe();
      if (result['success'] == true && result['user'] != null) {
        _user = UserModel.fromJson(result['user'] as Map<String, dynamic>);
        _username = _user!.username;
        notifyListeners();
      }
    } catch (e) {
      debugPrint('AuthService.loadUser error: $e');
    }
  }
}
