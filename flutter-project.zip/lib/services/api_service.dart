import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const String _tokenKey = 'sync_token';

  final String baseUrl;
  String? _token;

  ApiService({String? baseUrl})
      : baseUrl = baseUrl ?? _resolveBaseUrl();

  static String _resolveBaseUrl() {
    if (kIsWeb) {
      return '';
    }
    return 'http://localhost:3000';
  }

  // ---------------------------------------------------------------------------
  // Token management
  // ---------------------------------------------------------------------------

  Future<void> _loadToken() async {
    if (_token != null) return;
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString(_tokenKey);
  }

  Future<void> _saveToken(String token) async {
    _token = token;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
  }

  Future<void> _clearToken() async {
    _token = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
  }

  String? get token => _token;

  // ---------------------------------------------------------------------------
  // HTTP helpers
  // ---------------------------------------------------------------------------

  Map<String, String> _headers({bool auth = true}) {
    final headers = <String, String>{
      'Content-Type': 'application/json',
    };
    if (auth && _token != null) {
      headers['x-auth-token'] = _token!;
    }
    return headers;
  }

  Future<Map<String, dynamic>> _get(String path) async {
    await _loadToken();
    final uri = Uri.parse('$baseUrl$path');
    final response = await http.get(uri, headers: _headers());
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> _post(
    String path, {
    Map<String, dynamic>? body,
    bool auth = true,
  }) async {
    await _loadToken();
    final uri = Uri.parse('$baseUrl$path');
    final response = await http.post(
      uri,
      headers: _headers(auth: auth),
      body: body != null ? jsonEncode(body) : null,
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> _delete(String path) async {
    await _loadToken();
    final uri = Uri.parse('$baseUrl$path');
    final response = await http.delete(uri, headers: _headers());
    return _handleResponse(response);
  }

  Map<String, dynamic> _handleResponse(http.Response response) {
    final Map<String, dynamic> data;
    try {
      data = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      return {
        'success': false,
        'statusCode': response.statusCode,
        'message': response.body,
      };
    }
    data['statusCode'] = response.statusCode;
    if (response.statusCode >= 200 && response.statusCode < 300) {
      data['success'] = data['success'] ?? true;
    } else {
      data['success'] = false;
    }
    return data;
  }

  // ---------------------------------------------------------------------------
  // Auth endpoints
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>> login(
    String username,
    String password,
    String deviceId,
  ) async {
    final result = await _post(
      '/api/auth/login',
      body: {
        'username': username,
        'password': password,
        'deviceId': deviceId,
      },
      auth: false,
    );
    if (result['success'] == true && result['token'] != null) {
      await _saveToken(result['token'] as String);
    }
    return result;
  }

  Future<Map<String, dynamic>> logout() async {
    final result = await _post('/api/auth/logout');
    await _clearToken();
    return result;
  }

  Future<Map<String, dynamic>> changePassword(
    String oldPassword,
    String newPassword,
  ) async {
    return _post('/api/auth/change-password', body: {
      'oldPassword': oldPassword,
      'newPassword': newPassword,
    });
  }

  // ---------------------------------------------------------------------------
  // User endpoints
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>> getMe() async {
    return _get('/api/me');
  }

  // ---------------------------------------------------------------------------
  // Device endpoints
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>> getDevices() async {
    return _get('/api/devices');
  }

  Future<Map<String, dynamic>> sendCommand(
    String deviceId,
    String command,
    dynamic value,
  ) async {
    return _post('/api/devices/$deviceId/command', body: {
      'command': command,
      'value': value,
    });
  }

  // ---------------------------------------------------------------------------
  // Admin endpoints
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>> getAdminAccounts() async {
    return _get('/api/admin/accounts');
  }

  Future<Map<String, dynamic>> createAccount(
    String username,
    String password,
    String role,
    int trialDuration,
  ) async {
    return _post('/api/admin/accounts', body: {
      'username': username,
      'password': password,
      'role': role,
      'trialDuration': trialDuration,
    });
  }

  Future<Map<String, dynamic>> deleteAccount(String username) async {
    return _delete('/api/admin/accounts/$username');
  }

  Future<Map<String, dynamic>> getAdminQuota() async {
    return _get('/api/admin/quota');
  }

  // ---------------------------------------------------------------------------
  // Order endpoints
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>> createOrder(
    String role,
    String username,
    String password,
  ) async {
    return _post('/api/orders', body: {
      'role': role,
      'username': username,
      'password': password,
    });
  }

  Future<Map<String, dynamic>> getOrderStatus(String invoiceId) async {
    return _get('/api/orders/$invoiceId');
  }

  Future<Map<String, dynamic>> completeOrder(
    String invoiceId,
    String username,
    String password,
    String role,
  ) async {
    return _post('/api/orders/$invoiceId/complete', body: {
      'username': username,
      'password': password,
      'role': role,
    });
  }

  // ---------------------------------------------------------------------------
  // Helper endpoints
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>> createHelper(
    String username,
    int amount,
  ) async {
    return _post('/api/helpers', body: {
      'username': username,
      'amount': amount,
    });
  }

  Future<Map<String, dynamic>> getHelperStatus(String invoiceId) async {
    return _get('/api/helpers/$invoiceId');
  }

  Future<Map<String, dynamic>> completeHelper(
    String invoiceId,
    String username,
  ) async {
    return _post('/api/helpers/$invoiceId/complete', body: {
      'username': username,
    });
  }
}
