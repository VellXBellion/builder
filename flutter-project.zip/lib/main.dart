import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:genetic_app/theme/app_theme.dart';
import 'package:genetic_app/services/auth_service.dart';
import 'package:genetic_app/services/socket_service.dart';
import 'package:genetic_app/screens/splash_screen.dart';
import 'package:genetic_app/screens/login_screen.dart';
import 'package:genetic_app/screens/home_screen.dart';
import 'package:genetic_app/screens/admin_panel_screen.dart';
import 'package:genetic_app/screens/settings_screen.dart';
import 'package:genetic_app/screens/about_screen.dart';
import 'package:genetic_app/screens/order_screen.dart';
import 'package:genetic_app/screens/helper_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppTheme.bgDeepest,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const GeneticApp());
}

class GeneticApp extends StatelessWidget {
  const GeneticApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => SocketService()),
      ],
      child: MaterialApp(
        title: 'GENETIC',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkPurple,
        initialRoute: '/splash',
        routes: {
          '/splash': (_) => const SplashScreen(),
          '/login': (_) => const LoginScreen(),
          '/home': (_) => const HomeScreen(),
          '/admin': (_) => const AdminPanelScreen(),
          '/settings': (_) => const SettingsScreen(),
          '/about': (_) => const AboutScreen(),
          '/order': (_) => const OrderScreen(),
          '/helper': (_) => const HelperScreen(),
        },
      ),
    );
  }
}
