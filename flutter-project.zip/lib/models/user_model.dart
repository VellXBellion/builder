class UserModel {
  final String username;
  final String displayName;
  final String role;
  final String uid;
  final DateTime? trialExpiry;
  final bool smooth;
  final DateTime? createdAt;
  final String? createdBy;

  UserModel({
    required this.username,
    required this.displayName,
    required this.role,
    required this.uid,
    this.trialExpiry,
    this.smooth = false,
    this.createdAt,
    this.createdBy,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      username: json['username'] as String? ?? '',
      displayName: json['displayName'] as String? ?? '',
      role: json['role'] as String? ?? 'user',
      uid: json['uid'] as String? ?? '',
      trialExpiry: json['trialExpiry'] != null
          ? DateTime.tryParse(json['trialExpiry'].toString())
          : null,
      smooth: json['smooth'] as bool? ?? false,
      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt'].toString())
          : null,
      createdBy: json['createdBy'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'username': username,
      'displayName': displayName,
      'role': role,
      'uid': uid,
      'trialExpiry': trialExpiry?.toIso8601String(),
      'smooth': smooth,
      'createdAt': createdAt?.toIso8601String(),
      'createdBy': createdBy,
    };
  }

  UserModel copyWith({
    String? username,
    String? displayName,
    String? role,
    String? uid,
    DateTime? trialExpiry,
    bool? smooth,
    DateTime? createdAt,
    String? createdBy,
  }) {
    return UserModel(
      username: username ?? this.username,
      displayName: displayName ?? this.displayName,
      role: role ?? this.role,
      uid: uid ?? this.uid,
      trialExpiry: trialExpiry ?? this.trialExpiry,
      smooth: smooth ?? this.smooth,
      createdAt: createdAt ?? this.createdAt,
      createdBy: createdBy ?? this.createdBy,
    );
  }

  @override
  String toString() {
    return 'UserModel(username: $username, displayName: $displayName, role: $role, uid: $uid)';
  }
}
