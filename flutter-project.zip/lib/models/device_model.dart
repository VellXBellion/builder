class DeviceModel {
  final String deviceId;
  final String name;
  final int battery;
  final bool charging;
  final int sdkVersion;
  final String androidVersion;
  final String uid;
  final bool online;
  final String phoneNumber;

  DeviceModel({
    required this.deviceId,
    required this.name,
    this.battery = 0,
    this.charging = false,
    this.sdkVersion = 0,
    this.androidVersion = '',
    this.uid = '',
    this.online = false,
    this.phoneNumber = '',
  });

  factory DeviceModel.fromJson(Map<String, dynamic> json) {
    return DeviceModel(
      deviceId: json['deviceId'] as String? ?? '',
      name: json['name'] as String? ?? 'Unknown Device',
      battery: (json['battery'] as num?)?.toInt() ?? 0,
      charging: json['charging'] as bool? ?? false,
      sdkVersion: (json['sdkVersion'] as num?)?.toInt() ?? 0,
      androidVersion: json['androidVersion'] as String? ?? '',
      uid: json['uid'] as String? ?? '',
      online: json['online'] as bool? ?? false,
      phoneNumber: json['phoneNumber'] as String? ?? '',
    );
  }

  DeviceModel copyWith({
    String? deviceId,
    String? name,
    int? battery,
    bool? charging,
    int? sdkVersion,
    String? androidVersion,
    String? uid,
    bool? online,
    String? phoneNumber,
  }) {
    return DeviceModel(
      deviceId: deviceId ?? this.deviceId,
      name: name ?? this.name,
      battery: battery ?? this.battery,
      charging: charging ?? this.charging,
      sdkVersion: sdkVersion ?? this.sdkVersion,
      androidVersion: androidVersion ?? this.androidVersion,
      uid: uid ?? this.uid,
      online: online ?? this.online,
      phoneNumber: phoneNumber ?? this.phoneNumber,
    );
  }

  @override
  String toString() {
    return 'DeviceModel(deviceId: $deviceId, name: $name, online: $online, battery: $battery%)';
  }
}
