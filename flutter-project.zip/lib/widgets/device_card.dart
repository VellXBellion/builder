import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:genetic_app/theme/app_theme.dart';
import 'package:genetic_app/models/device_model.dart';

class DeviceCard extends StatelessWidget {
  final DeviceModel device;
  final bool isSelected;
  final VoidCallback? onTap;

  const DeviceCard({
    super.key,
    required this.device,
    this.isSelected = false,
    this.onTap,
  });

  Color get _batteryColor {
    if (device.battery > 60) return AppTheme.green;
    if (device.battery > 20) return AppTheme.amber;
    return AppTheme.red;
  }

  String get _truncatedId {
    if (device.deviceId.length <= 12) return device.deviceId;
    return '${device.deviceId.substring(0, 12)}...';
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isSelected
                ? [
                    AppTheme.violet.withOpacity(0.18),
                    AppTheme.bgMid.withOpacity(0.9),
                  ]
                : [
                    const Color(0xFF1A1040).withOpacity(0.85),
                    const Color(0xFF0E0A20).withOpacity(0.95),
                  ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected
                ? AppTheme.violet.withOpacity(0.6)
                : AppTheme.glassBorder2,
            width: isSelected ? 1.5 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
            if (isSelected)
              BoxShadow(
                color: AppTheme.violet.withOpacity(0.12),
                blurRadius: 20,
                spreadRadius: 2,
              ),
          ],
        ),
        child: Row(
          children: [
            // Phone icon with 3D shadow
            _buildPhoneIcon(),
            const SizedBox(width: 14),

            // Info column
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Device name + online dot
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          device.name,
                          style: GoogleFonts.rajdhani(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.textPrimary,
                            letterSpacing: 0.5,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 6),
                      _buildOnlineDot(),
                    ],
                  ),
                  const SizedBox(height: 4),

                  // Device ID
                  Text(
                    _truncatedId,
                    style: GoogleFonts.spaceMono(
                      fontSize: 9,
                      color: AppTheme.textMuted,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 2),

                  // Android version
                  if (device.androidVersion.isNotEmpty)
                    Text(
                      'Android ${device.androidVersion}',
                      style: GoogleFonts.outfit(
                        fontSize: 11,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                  const SizedBox(height: 8),

                  // Battery bar
                  _buildBatteryBar(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhoneIcon() {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.violet.withOpacity(0.15),
            AppTheme.bgMid.withOpacity(0.6),
          ],
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 8,
            offset: const Offset(2, 4),
          ),
          BoxShadow(
            color: AppTheme.violet.withOpacity(0.08),
            blurRadius: 12,
            offset: const Offset(-1, -1),
          ),
        ],
      ),
      child: Icon(
        Icons.phone_android_rounded,
        color: isSelected ? AppTheme.violet : AppTheme.violetLight,
        size: 24,
      ),
    );
  }

  Widget _buildOnlineDot() {
    final color = device.online ? AppTheme.green : AppTheme.textMuted;
    return Container(
      width: 10,
      height: 10,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: device.online
            ? [
                BoxShadow(
                  color: color.withOpacity(0.6),
                  blurRadius: 6,
                  spreadRadius: 1,
                ),
              ]
            : null,
      ),
    );
  }

  Widget _buildBatteryBar() {
    return Row(
      children: [
        Icon(
          device.charging ? Icons.bolt_rounded : Icons.battery_std_rounded,
          size: 12,
          color: _batteryColor,
        ),
        const SizedBox(width: 6),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: SizedBox(
              height: 5,
              child: LinearProgressIndicator(
                value: device.battery / 100,
                backgroundColor: AppTheme.bgLight.withOpacity(0.5),
                valueColor: AlwaysStoppedAnimation<Color>(_batteryColor),
              ),
            ),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          '${device.battery}%',
          style: GoogleFonts.spaceMono(
            fontSize: 9,
            color: _batteryColor,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
