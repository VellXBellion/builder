package com.genetic.genetic_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
